#!/usr/bin/env node
//
// checkpoint-a.js -- WP-SEMINUM-01 activity 2, the governance smoke test
// for a germinated practice. Issue #59, realizes INT-002.
//
// WHAT IT PROVES, and the wording matters because a smoke test that
// overclaims is worse than none. It runs CHARTER-CC §6 Step 0b's four
// signals against a repo tree and reports whether that tree is a
// GERMINATED PRACTICE, a BROKEN CLONE, or NEITHER -- and in germination
// mode it prints the refusal David ratified: no work can be dispatched
// or closed until S0 is authored.
//
// CHECKPOINT A IS COMPLETE AS OF 2026-08-15 (issue #60). DTOG's
// definition is "Hello World, live S0 recitation, repo name". All three
// are delivered. The recitation was BLOCKED until David authored the
// test practice's S0 in response to CHARTER-DT §0 Step 1G -- this tool
// is forbidden from supplying one ("S0 is the owner's to author, and CC
// does not draft it") and stopped at that handoff, which was Step 1G's
// first live execution against a real tree. When there is no S0 it still
// stops there and says so.
//
// THE TRANSITION IS THE RESULT WORTH READING. Before S0: the fiber probe
// returned `ok: false` and every typed item was refusable. After: the
// same probe resolves. The discipline released on its own terms rather
// than being switched off.
//
// INSTRUMENTS, NOT REIMPLEMENTATIONS. The signals are evaluated with
// tools/lib/corpus-parser.js -- the same parse core validate-corpus.js
// and Vellum read through -- pointed at a different rootDir, which it
// already takes as a parameter. The dispatch refusal is demonstrated
// with tools/lib/fiber-check.js, the live module. If either changes,
// this checkpoint changes with it rather than drifting from it. A
// hand-rolled scan of the germinated tree would have been easier and
// would have proved nothing about the machinery that actually governs.
//
// WHY THE FIXTURE IS SAFE TO KEEP IN THIS REPO. parseCorpus reads
// <root>/corpus and <root>/spec with a FLAT readdirSync, so
// checkpoints/a/repo/corpus/*.md is invisible to the governed corpus's
// own validator and census. Verified by running both after the fixture
// landed, not assumed.
//
// ---------------------------------------------------------------------
// HOW THIS CONTROL CAN BE CROSSED (RULE-10)
//
//   1. IT IS A REPORTER, NOT A GATE. Nothing consumes its exit code and
//      no workflow invokes it. It tells a human what a tree is; it
//      refuses nobody. Called a "smoke test" advisedly.
//   2. The fixture is a COPY of four pattern-layer files taken
//      2026-08-15. If corpus/rules.md or the charters change, the
//      fixture silently keeps the old text and this checkpoint goes on
//      passing against a practice that no longer exists. There is no
//      drift check. Re-copy with --refresh, or accept the snapshot and
//      say which date it is from.
//   3. It tests SIGNAL PRESENCE, not seed correctness. A tree can be
//      germinated by these four signals and still be an unusable seed --
//      wrong files, truncated content, a charter without its §0. That is
//      WP-SEMINUM-02 activity 5's job, not this one's.
//   4. Signal 3 checks briefs/ and briefs/digests/ by directory
//      existence and name pattern only. A briefs/ containing unrelated
//      files that are not exchange folders reads as empty.
// ---------------------------------------------------------------------

const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..');
const yaml = require(path.join(ROOT, 'tools', 'node_modules', 'js-yaml'));
const { parseCorpus } = require(path.join(ROOT, 'tools', 'lib', 'corpus-parser.js'));
const { checkFiber } = require(path.join(ROOT, 'tools', 'lib', 'fiber-check.js'));

const os = require('os');

const args = process.argv.slice(2);
const rootArg = args.indexOf('--root');
const SELF_TEST = args.includes('--self-test');
// THE DEFAULT ROOT IS THE REPOSITORY THIS FILE SHIPS IN, not a fixture.
//
// It used to default to `checkpoints/a/repo`, the originating practice's
// own test fixture -- a path that exists in exactly one repository in the
// world. So a recipient following MANIFEST.md's germination check, which
// says `node tools/checkpoint-a.js` and "expect pass", got
// "REFUSE: no tree at that path" and exit 2. THE SEED SHIPPED AN
// INSTRUCTION IT COULD NOT SATISFY -- the third of that kind after the
// missing package.json and the archive's directory prefix.
//
// Found by this file's own --self-test, run inside a built bundle rather
// than in the repository that authored it. The case passes here and failed
// there, which is the only way that defect was ever going to surface.
//
// The fixture is still reachable: --root checkpoints/a/repo.
//
// REFUSE RATHER THAN DISCARD. A bare positional was silently ignored, so
// `checkpoint-a.js /their/repo` reported on THIS file's own directory and
// produced a verdict about the wrong tree BYTE-IDENTICAL to a correct one.
// CC hit it four times in one session while measuring something else, and
// nearly reported that signal 1 zeroes out on a valid corpus. A competent
// user of this tool got a confident wrong answer from it; that is not a
// documentation problem. The loud failure beside it -- `--root` with no
// value throwing ERR_INVALID_ARG_TYPE -- is the lesser defect of the two.
const KNOWN = ['--root', '--self-test'];
const stray = args.filter((a, i) =>
  !KNOWN.includes(a) && !(rootArg >= 0 && i === rootArg + 1));
if (stray.length) {
  console.error('REFUSED -- unrecognised argument: ' + stray[0]);
  console.error('  To check another tree:  --root <path>');
  process.exit(2);
}
if (rootArg >= 0 && !args[rootArg + 1]) {
  console.error('REFUSED -- --root requires a path.');
  process.exit(2);
}
const TREE = path.resolve(rootArg >= 0 ? args[rootArg + 1] : ROOT);

// ---------------------------------------------------------------------
// THE STATE MODEL (OI-057, adopted 2026-08-21)
//
// Step 0b named three outcomes and swept everything else into NEITHER.
// That was wrong in a specific and measurable way: THE STATE GERMINATION
// PRODUCES fell into NEITHER. Once an owner authors S0 in response to
// Step 1G, the tree reports "the signals disagree" -- so the successful
// outcome of germination read as a suspected transport failure, and once
// the practice wrote its first brief the tool exited non-zero while all
// three of its own criteria passed.
//
// THE MODEL BELOW WAS NOT INVENTED HERE. It was built by a practice
// GERMINATED FROM THIS CORPUS -- the fourth such germination -- whose
// architecture role drafted it, whose owner ratified it, and whose
// execution role built and tested it. This practice's own execution role
// had correctly refused to invent a fifth verdict, because naming states
// is S1 semantics and CHARTER-CC §2 reserves that to David. THE CYCLE
// PRODUCED WHAT A UNILATERAL DECISION WAS FORBIDDEN FROM PRODUCING.
//
// ADOPTED AS A MODEL, NOT AS A DIFF. Their verdict and guidance text is
// theirs; the words below are ours, written against our own Step 0b.
// Lifting their file would have imported a germinated practice's content
// into this corpus -- the extraction-versus-authoring line arriving from
// the opposite direction.
//
// ONE STATE RESULT DRIVES EVERYTHING: verdict, guidance, the completion
// block, and the exit code. Before this, four booleans drove four
// separate decisions and they could disagree.
// ---------------------------------------------------------------------
function classify(o) {
  const anyHistory = o.hasS0 || o.hasActiveRoadmap || o.hasExchange || o.hasDigest;
  if (o.parseError) return 'invalid';
  if (!anyHistory) return o.patternLayer ? 'clean-germination' : 'broken-handoff';
  if (!o.patternLayer) return 'invalid';
  if (o.hasS0 && !o.hasExchange) return 's0-transition';
  if (o.hasS0 && o.hasExchange) return 'post-germination';
  return 'mixed';
}

// A healthy state is one a practice can legitimately be in. It is not the
// same as "the checkpoint passes" -- a clean seed is healthy and its
// checkpoint is incomplete, because there is no S0 to recite yet.
const HEALTHY = ['clean-germination', 's0-transition', 'post-germination'];

function stateText(state) {
  return {
    'clean-germination': {
      verdict: 'VERDICT: CLEAN GERMINATION. All four signals hold.',
      guidance: 'The practice has no intent of its own yet. Nothing can be '
        + 'dispatched or closed until the owner authors S0.',
    },
    'broken-handoff': {
      verdict: 'VERDICT: BROKEN HANDOFF, not germination.',
      guidance: 'History is absent AND the pattern layer is missing -- signal '
        + '(4) is what separates the two. Stop and ask for the missing record.',
    },
    's0-transition': {
      verdict: 'VERDICT: S0-AUTHORING TRANSITION.',
      guidance: 'S0 exists and its refusal has lifted; no exchange has been '
        + 'written yet. This is what Step 1G leaves behind and it is expected, '
        + 'not a fault.',
    },
    'post-germination': {
      verdict: 'VERDICT: ORDINARY POST-GERMINATION.',
      guidance: 'S0 and a first exchange both exist. Germination has ended and '
        + 'ordinary reconstitution applies; Step 0b does not fire.',
    },
    invalid: {
      verdict: 'VERDICT: INVALID OR INCOMPLETE RECORD.',
      guidance: 'Either the corpus did not parse, or history exists without the '
        + 'pattern layer. Resolve the concrete missing or malformed condition '
        + 'before reading anything else here as meaningful.',
    },
    mixed: {
      verdict: 'VERDICT: NEITHER -- an unsettled mixed state.',
      guidance: 'History exists but no S0 does. Stop and ask rather than '
        + 'inferring history from conflicting signals: this is the case most '
        + 'likely to be a transport failure wearing germination\'s clothes.',
    },
  }[state];
}

function exists(p) { return fs.existsSync(path.join(TREE, p)); }
function say(s) { console.log(s); }
function wrap(t, w = 70) {
  const out = []; let line = '';
  for (const word of String(t).split(/\s+/)) {
    if (!line) { line = word; continue; }
    if ((line + ' ' + word).length > w) { out.push(line); line = word; } else line += ' ' + word;
  }
  if (line) out.push(line);
  return out;
}


// ---------------------------------------------------------------------
// --self-test: nine states, driven through this file's own entry point
//
// IT SPAWNS RATHER THAN CALLS. Each case writes a temporary tree, runs
// THIS SCRIPT against it as a child process, and reads the verdict and
// the exit code. That tests the thing a recipient actually runs --
// argument parsing, the parse core, the classifier and the exit
// expression together -- where an in-process call would test a function
// and leave the wiring unproven.
//
// THE FIXTURES ARE TEMPORARY AND REMOVED. Nothing is written inside the
// repository, so running this cannot disturb a governed tree.
//
// WHY NINE. Six are the states classify() can return; the other three
// are the ways this tool can be invoked wrongly -- a corpus that does
// not parse, a path with no tree, and no arguments at all. A state model
// that is only tested on well-formed input is not tested on the cases it
// exists for.
// ---------------------------------------------------------------------
function fixture(dir, opts) {
  const w = (rel, body) => {
    const full = path.join(dir, rel);
    fs.mkdirSync(path.dirname(full), { recursive: true });
    fs.writeFileSync(full, body, 'utf8');
  };
  const sheet = (id, type, items, extra) =>
    '---\ntype: ' + type + '\nid: "' + id + '"\ntitle: "' + id + '"\n' +
    (extra || '') + '---\n\n' + items;
  // FIXTURE-*, never a real acknowledgement: the self-test exercises both
  // states without any tree it builds ever carrying an owner's actual act.
  const ackLine = opts.acknowledged
    ? 'germination_acknowledged: "2026-01-01, FIXTURE-OWNER"\n'
    : '';

  // spec/ must exist either way: parseCorpus scans it, and a tree without
  // it cannot be parsed at all -- which is 'invalid', not 'broken handoff'.
  w('spec/.keep', '');
  if (opts.patternLayer !== false) {
    w('corpus/rules.md', sheet('SHEET-RULES', 'constraint_or_principle',
      'items:\n  - id: "RULE-1"\n    title: "A rule"\n    cp_kind: "Rule"\n    cp_statement: "Something."\n'));
    w('spec/strata-and-intent-fibering.md', '---\ntype: constraint_or_principle\nid: "SPEC-STRATA"\ntitle: "Strata"\n---\n\nBody.\n');
  }
  w('corpus/intent_register.md', opts.badYaml
    ? '---\ntype: constraint_or_principle\nid: "INTENT"\ntitle: "I"\n---\n\nitems:\n  - id: "FIXTURE-1"\n    title: "x"\n  bad: [\n   - unclosed\n\t- tab\n'
    : sheet('INTENT', 'constraint_or_principle', opts.hasS0
      ? 'items:\n  - id: "FIXTURE-2"\n    title: "Why this practice exists"\n    cp_kind: "Intent"\n    status: "Active"\n    intent_statement: "A reason."\n'
      : 'items: []\n', ackLine));
  w('corpus/roadmap.md', sheet('ROADMAP', 'roadmap_entry', opts.activeRoadmap
    ? 'items:\n  - id: "FIXTURE-3"\n    title: "Work"\n    status: "Active"\n'
    : 'items: []\n'));
  if (opts.exchange) w('briefs/2026-01-01-first/01-DT-brief.md', '# brief\n');
}

function selfTest() {
  const { execFileSync } = require('child_process');
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'checkpoint-a-self-test-'));
  const cases = [
    ['clean-seed', {}, 'CLEAN GERMINATION', 1],
    ['broken-handoff', { patternLayer: false }, 'BROKEN HANDOFF', 1],
    ['s0-transition', { hasS0: true }, 'S0-AUTHORING TRANSITION', 0],
    ['post-germination-empty-roadmap', { hasS0: true, exchange: true }, 'ORDINARY POST-GERMINATION', 0],
    ['post-germination-active-roadmap', { hasS0: true, exchange: true, activeRoadmap: true }, 'ORDINARY POST-GERMINATION', 0],
    ['history-pattern-missing', { hasS0: true, exchange: true, patternLayer: false }, 'INVALID OR INCOMPLETE', 1],
    ['parser-error', { badYaml: true }, 'INVALID OR INCOMPLETE', 1],
    // Both acknowledgement states, exit 0 either way -- choice (a) ruled
    // 2026-08-22. If either of these ever expects 1, the ruling changed and
    // this table is where that is visible.
    ['awaiting-acknowledgement', { hasS0: true }, 'AWAITING OWNER ACKNOWLEDGEMENT', 0],
    ['acknowledged', { hasS0: true, acknowledged: true }, 'ACKNOWLEDGED -- practice live', 0],
  ];

  const run = (extra) => {
    try {
      return { out: execFileSync(process.execPath, [__filename].concat(extra), { encoding: 'utf8' }), code: 0 };
    } catch (e) {
      return { out: String(e.stdout || ''), code: e.status };
    }
  };

  say('CHECKPOINT A SELF-TEST');
  let pass = 0;
  for (const [name, opts, wantVerdict, wantCode] of cases) {
    const dir = path.join(tmp, name);
    fixture(dir, opts);
    const r = run(['--root', dir]);
    const ok = r.out.includes(wantVerdict) && r.code === wantCode;
    say('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + name
      + (ok ? '' : '  expected ' + wantVerdict + '/' + wantCode + ', got exit ' + r.code));
    if (ok) pass++;
  }

  // the three invocation cases
  const missing = run(['--root', path.join(tmp, 'no-such-tree')]);
  const okMissing = missing.code === 2 && missing.out.includes('REFUSE');
  say('  [' + (okMissing ? 'PASS' : 'FAIL') + '] missing-tree');
  if (okMissing) pass++;

  // Runs with no arguments at all: the default root must resolve to a real
  // tree in WHATEVER repository this file is sitting in, or the germination
  // check a recipient is told to run cannot run.
  const noArgs = run([]);
  const okNoArgs = /VERDICT:/.test(noArgs.out) && noArgs.code !== 2;
  say('  [' + (okNoArgs ? 'PASS' : 'FAIL') + '] no-arguments-default-root');
  if (okNoArgs) pass++;

  const help = run(['--root', tmp]);
  const okEmpty = /VERDICT:/.test(help.out);
  say('  [' + (okEmpty ? 'PASS' : 'FAIL') + '] empty-directory-is-classified');
  if (okEmpty) pass++;

  fs.rmSync(tmp, { recursive: true, force: true });
  const total = cases.length + 3;
  say('RESULT: ' + pass + '/' + total + ' passed');
  process.exit(pass === total ? 0 : 1);
}

if (SELF_TEST) selfTest();

say('CHECKPOINT A -- governance smoke test for a germinated practice');
say('');
say('Hello World.');
say('');
say('  repo name : ' + path.basename(TREE));
say('  tree root : ' + TREE);
if (!fs.existsSync(TREE)) {
  say('');
  say('REFUSE: no tree at that path. Nothing to test.');
  process.exit(2);
}

// ---- Signals, per CHARTER-CC §6 Step 0b / CHARTER-DT §0 Step 0b ----
let parsed = null, parseNote = '';
try {
  parsed = parseCorpus(TREE, yaml);
} catch (e) {
  parseNote = e.message;
}

const intentItems = parsed
  ? (parsed.files.find((f) => f.file === 'intent_register.md')?.items || [])
  : [];
const roadmapItems = parsed
  ? (parsed.files.find((f) => f.file === 'roadmap.md')?.items || [])
  : [];
const liveWP = roadmapItems.filter((i) => ['Active', 'Ready'].includes(i.status));

const briefsDir = path.join(TREE, 'briefs');
const exchangeFolders = fs.existsSync(briefsDir)
  ? fs.readdirSync(briefsDir).filter((d) => /^\d{4}-\d{2}-\d{2}-/.test(d))
  : [];
const digestsDir = path.join(briefsDir, 'digests');
const digests = fs.existsSync(digestsDir)
  ? fs.readdirSync(digestsDir).filter((f) => f.startsWith('SD-'))
  : [];

const fileParseErrors = parsed && Array.isArray(parsed.parseErrors)
  ? parsed.parseErrors
  : [];

const signals = [
  {
    n: 1,
    text: 'intent_register.md absent, or present with no INT-* items',
    ok: !exists('corpus/intent_register.md') || intentItems.length === 0,
    saw: exists('corpus/intent_register.md')
      ? `present, ${intentItems.length} INT-* item(s)`
      : 'absent',
  },
  {
    n: 2,
    text: 'roadmap.md has no Active or Ready items',
    ok: liveWP.length === 0,
    saw: exists('corpus/roadmap.md')
      ? `present, ${liveWP.length} Active/Ready`
      : 'absent (trivially none)',
  },
  {
    n: 3,
    text: 'briefs/ has no exchange folders and briefs/digests/ no SD-*',
    ok: exchangeFolders.length === 0 && digests.length === 0,
    saw: `${exchangeFolders.length} exchange folder(s), ${digests.length} SD-* digest(s)`,
  },
  {
    n: 4,
    text: 'corpus/rules.md and SPEC-STRATA ARE present',
    ok: exists('corpus/rules.md') && exists('spec/strata-and-intent-fibering.md'),
    saw: `rules.md ${exists('corpus/rules.md') ? 'present' : 'ABSENT'}, SPEC-STRATA ${
      exists('spec/strata-and-intent-fibering.md') ? 'present' : 'ABSENT'}`,
  },
];

say('');
say('Step 0b -- four signals, evaluated by the live parse core:');
for (const s of signals) {
  say(`  ${s.ok ? 'YES' : 'no '}  (${s.n}) ${s.text}`);
  say(`        saw: ${s.saw}`);
}
if (parseNote) say(`  NOTE: parse core reported: ${parseNote}`);
for (const e of fileParseErrors) say('  PARSE ERROR: ' + e);

// The four signals are stated as ABSENCES -- "no INT-* items", "no Active
// or Ready", "no exchange folders". The state model reasons about
// PRESENCE, so the observations invert them once, here, rather than each
// branch inverting them again and getting one wrong.
const observations = {
  hasS0: !signals[0].ok,
  hasActiveRoadmap: !signals[1].ok,
  hasExchange: exchangeFolders.length > 0,
  hasDigest: digests.length > 0,
  patternLayer: signals[3].ok,
  // parseCorpus THROWS only when a directory is missing. Malformed YAML
  // inside a file is RETURNED in parseErrors[] and the parse "succeeds" --
  // so a corpus whose intent_register.md does not parse yields zero items,
  // signal (1) reads that as "no S0", and the tree reports CLEAN
  // GERMINATION. A PARSE FAILURE WAS INDISTINGUISHABLE FROM A CLEAN SEED.
  // Caught by this file's own self-test on its first run, not by review.
  parseError: Boolean(parseNote) || fileParseErrors.length > 0,
};
const state = classify(observations);
const text = stateText(state);

// NOTHING EXITS IN THIS BLOCK. The S0 recitation below is checkpoint A's
// third criterion and must run whatever the verdict. An earlier version
// exited here, so the tree that had just been given an S0 -- the only
// tree that CAN recite one -- returned before reciting it. Caught by
// running, issue #60.

say('');
say(text.verdict);
for (const line of wrap(text.guidance)) say('  ' + line);

// ---- S0 recitation: checkpoint A's third criterion ----
const s0 = intentItems;
say('');
if (s0.length) {
  say('LIVE S0 RECITATION -- read from the parse core at run time:');
  say('');
  for (const i of s0) {
    const stmt = String(i.intent_statement || '').trim().replace(/\s+/g, ' ');
    say(`  ${i.id} -- ${i.title}`);
    say(`     "${stmt}"`);
  }
  say('');
  say(`  ${s0.length} statement(s), owner-authored. This practice can`);
  say('  recite its own intent.');
} else {
  say('LIVE S0 RECITATION: none -- there is no S0 to recite.');
}

// ---- The refusal, demonstrated rather than asserted ----
say('');
say('THE REFUSAL, run against the live fiber checker rather than quoted:');
// INT-X01, not FIXTURE-*: this probe teaches by naming an id that LOOKS
// REAL AND IS ABSENT. A FIXTURE- id looks synthetic, which is the one
// property it must not have. It clears every emit-screen token under both
// anchorings because INT-[0-9]+ is digit-anchored and the X breaks it.
const probe = { type: 'work_item', realizes: 'INT-X01', strata: ['S6'] };
// `parsed` is null when parseCorpus threw -- guarded at :98-:102 and, until
// 2026-08-19, dereferenced bare here. So the tool CRASHED IN THE ONE
// SITUATION IT EXISTS FOR: a tree whose corpus does not fully parse. The
// guard was 130 lines earlier and stopped. Observed as a stack trace when a
// bundle shipped without spec/, and this file is an entry point, so the crash
// shipped with every seed.
//
// REPORTED AS UNRUNNABLE RATHER THAN SKIPPED SILENTLY: the probe's whole
// purpose is to demonstrate the refusal against the live checker, and a
// silent skip would leave the verdict line above asserting germination while
// the demonstration did not run. Drafted by DT2 in
// briefs/2026-08-18-seminum-packager/14- section 4.
const verdict = parsed
  ? checkFiber(probe, parsed.allIds, { requireStrata: true })
  : null;
say('  probe: ' + JSON.stringify(probe));
if (!verdict) {
  say('  NOT RUN -- the corpus did not parse, so there is no id universe to');
  say('  check against. ' + (parseNote || 'See the parse errors above.'));
  say('');
  say('  THIS IS NOT A PASS AND NOT A FAILURE. The refusal above is asserted');
  say('  and undemonstrated, which is exactly what this block exists to avoid.');
} else {
say('  ok: ' + verdict.ok);
for (const p of verdict.problems || []) say('   - ' + p);

say('');
if (!verdict.ok) {
  say('  NO WORK CAN BE DISPATCHED OR CLOSED UNTIL S0 IS AUTHORED.');
  say('  Every `realizes:` resolves against corpus/intent_register.md, and');
  say('  in a germinated repo there is nothing to resolve against -- so');
  say('  EVERY typed item fails, not because it is malformed but because');
  say('  the practice has no intent yet.');
} else {
  // The third defect this tool's own runs have caught. Until issue #60
  // this refusal printed unconditionally, so the run that PROVED the
  // refusal had lifted still announced it -- contradicting the probe
  // result on the line above.
  say('  THE REFUSAL HAS LIFTED. The probe resolves against this');
  say('  practice\'s own S0, authored by its owner. Work can now be');
  say('  dispatched and closed here.');
  say('');
  say('  That transition is the point of the checkpoint: before the owner');
  say('  authored intent, every typed item failed the fiber check; after,');
  say('  they resolve. The discipline released on its own terms rather');
  say('  than being switched off.');
}
}   // end: the probe ran

// ---- Where this stops, and why ----
say('');
say('CHECKPOINT A -- the three criteria:');
say('  [x] Hello World');
say('  [x] repo name');
say(`  [${s0.length ? 'x' : ' '}] live S0 recitation`);
say('');
if (s0.length) {
  say('  COMPLETE. The S0 above was authored by the owner in response to');
  say('  CHARTER-DT §0 Step 1G and is recorded verbatim; CC did not');
  say('  pre-fill it, offer a menu, or carry another practice\'s INT-*');
  say('  across as an example.');
} else {
  say('  INCOMPLETE, and blocked by design. CHARTER-CC §6 Step 0b: "S0 is');
  say('  the owner\'s to author, and CC does not draft it." There is no S0');
  say('  and this tool is forbidden from inventing one. CHARTER-DT §0 Step');
  say('  1G governs the eliciting: ask the owner for three to five');
  say('  statements, in their own words, about why this practice exists.');
  say('  Never pre-fill, never offer a menu, never carry another');
  say('  practice\'s INT-* across as an example.');
}
// EXIT CODE SEMANTICS, stated because a smoke test whose code means
// something vague is worse than one with no code at all: 0 means THIS
// TREE PASSES CHECKPOINT A -- it is a germinated practice (or the shape
// germination leaves behind) AND all three criteria are met. Anything
// else is 1. The verdict above is reported either way; the code is about
// the checkpoint, not the verdict.
// ONE RESULT, not four booleans: a tree passes when its state is one a
// practice can legitimately be in AND it can recite its own intent. The
// old expression asked whether all four signals held OR a narrow
// carve-out matched -- and that carve-out required signal 3 to hold, so
// IT EXPIRED THE MOMENT THE PRACTICE FILED ITS FIRST BRIEF. A healthy
// practice then reported failure until it had enough history to stop
// looking new.
const checkpointPasses = HEALTHY.includes(state) && s0.length > 0;

// THE ACKNOWLEDGEMENT, and why it does not touch the exit code.
//
// The six-state model ends the young-practice state BY INFERENCE: the tree
// looks ordinary, so it is. David ruled that it ends BY AN ACT instead --
// dated, owned, and in governed text, which is how every other state in
// this estate terminates. So the question persists on every run until the
// owner answers it.
//
// Exit choice (a), ruled 2026-08-22: the line asks, it never fails.
// #115 restored exit 1's meaning -- SOMETHING IS WRONG -- and an
// unacknowledged healthy practice is not wrong. Re-attaching exit 1 to it
// would spend the meaning that change just bought. The alternative was put
// and declined: exit 1 until acknowledged would make every young practice
// fail CI until its owner acts.
//
// The field is READ here and never written. No tool sets it and no agent
// sets it; it is `key-only` in EXT-008 clause 6, so a seeded practice
// receives the key with an empty value and never the originating
// practice's answer.
const intentFront = parsed
  ? (parsed.files.find((f) => f.file === 'intent_register.md')?.front || {})
  : {};
const ack = typeof intentFront.germination_acknowledged === 'string'
  ? intentFront.germination_acknowledged.trim() : '';
if (checkpointPasses) {
  say('');
  say(ack
    ? `ACKNOWLEDGED -- practice live, ${ack}`
    : 'AWAITING OWNER ACKNOWLEDGEMENT -- when you judge this practice live,');
  if (!ack) {
    say('set `germination_acknowledged` in corpus/intent_register.md.');
    say('That is your act, not the tool\'s.');
  }
}

process.exit(checkpointPasses ? 0 : 1);
