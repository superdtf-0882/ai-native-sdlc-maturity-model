#!/usr/bin/env node
//
// checkpoint-b.js -- WP-SEMINUM-01 activity 3. Issue #61, realizes
// INT-002.
//
// DTOG's definition: "proof against something the practice doesn't
// control: live headlines from a free public RSS feed, no credential to
// provision or later decommission."
//
// THIS IS THE FIRST ARTIFACT IN THIS ESTATE TO REACH AN UNCONTROLLED
// EXTERNAL SERVICE AT RUNTIME. Everything else the practice runs reads
// its own repo.
//
// THE GOVERNANCE POINT, WHICH IS THE ACTUAL TEST. RSS titles are
// arbitrary third-party strings from a service nobody here operates.
// They are treated STRICTLY AS DATA TO DISPLAY: nothing parsed from the
// feed is executed, evaluated, interpolated into a shell or a query, or
// allowed to influence control flow. The only decisions this tool makes
// come from the HTTP status, the item COUNT, and the clock -- never from
// item content. A headline that reads like an instruction is a headline.
// That is what "survives contact with something it doesn't control" has
// to mean; without it the checkpoint would be a demonstration of the
// opposite.
//
// FEED SELECTION, tested live before choosing rather than assumed.
// Four candidates:
//   - .../rss/headlines/section/geo/<Country>  -> 200 WITH ZERO ITEMS.
//     A dead endpoint that looks healthy. This is why zero-items is a
//     LOUD failure below and not an empty list.
//   - .../rss/search?q=<Country>               -> answers "news ABOUT
//     the country", not "news IN it" -- a CNBC GDP note, a Wagyu farm
//     feature. Wrong semantic.
//   - .../rss?hl=ja&gl=JP&ceid=JP:ja           -> genuine Japan top
//     stories, in Japanese. Correct, and David redirected: "if the news
//     items come back in Japanese, that's less useful."
//   - .../rss?hl=en-AU&gl=AU&ceid=AU:en        -> genuine Australian
//     top stories, in English. CHOSEN.
// The general finding outlives the country: only the EDITION feed
// (hl/gl/ceid) means "top stories today, there."
//
// NO CREDENTIAL. Verifiable by reading the request below -- one GET, one
// User-Agent header, nothing else. Nothing to provision and nothing to
// decommission later, which is why DTOG specified RSS.
//
// ---------------------------------------------------------------------
// HOW THIS CONTROL CAN BE CROSSED (RULE-10)
//
//   1. IT IS A REPORTER, NOT A GATE. Nothing consumes its exit code.
//   2. IT DEPENDS ON A SERVICE THIS PRACTICE DOES NOT OPERATE. Google
//      may change the feed's shape, rate-limit, geo-restrict, or retire
//      the endpoint without notice -- the geo/ endpoint above already
//      did exactly that. A failure here is at least as likely to mean
//      "the world moved" as "this code broke", and the output says
//      which it saw.
//   3. THE PARSER IS A REGEX, NOT AN XML PARSER. Adequate for a
//      well-formed RSS 2.0 channel and stated plainly rather than
//      dressed up: nested CDATA, or a <title> containing an escaped
//      </title>, would defeat it. It never evaluates what it extracts,
//      so the failure mode is a mangled headline, not execution.
//   4. NO CACHING, NO RETRY, NO BACKOFF. One attempt, one timeout. A
//      transient network blip reads as failure. Deliberate: a checkpoint
//      that retries until it succeeds cannot tell you the service was
//      down.
//   5. IT SETS process.exitCode RATHER THAN CALLING process.exit().
//      Found by running: process.exit() inside the async body tore down
//      undici's still-closing sockets and produced a libuv assertion
//      plus EXIT 127 -- while the run had printed PASS. A tool whose
//      reported result and exit code disagree is worse than one that
//      fails outright, and this one did that on its first live run.
//   6. IT PRINTS THIRD-PARTY TEXT TO A TERMINAL. Headlines are
//      truncated and control characters stripped, so a crafted title
//      cannot rewrite the display around it.
// ---------------------------------------------------------------------

const FEEDS = {
  au: {
    url: 'https://news.google.com/rss?hl=en-AU&gl=AU&ceid=AU:en',
    label: 'Google News — Australia edition (en-AU)',
  },
  jp: {
    url: 'https://news.google.com/rss?hl=ja&gl=JP&ceid=JP:ja',
    label: 'Google News — Japan edition (ja-JP)',
  },
  // Test editions. Present so the failure paths can be PROVEN rather
  // than asserted -- a checkpoint whose error handling has never run is
  // a claim, not a control.
  'test-empty': {
    url: 'https://news.google.com/rss/headlines/section/geo/Japan?hl=en-US&gl=US&ceid=US:en',
    label: 'TEST -- the real dead endpoint that answers 200 with no items',
  },
  'test-unreachable': {
    url: 'https://this-host-does-not-exist.okf-togaf.invalid/rss',
    label: 'TEST -- an unroutable host, for the network-failure path',
  },
};

const args = process.argv.slice(2);
const pick = (flag, dflt) => {
  const i = args.indexOf(flag);
  return i >= 0 && args[i + 1] ? args[i + 1] : dflt;
};
const edition = pick('--edition', 'au');
const limit = parseInt(pick('--limit', '10'), 10);
const feed = FEEDS[edition];

const say = (s) => console.log(s);

// The user-agent sent to the feed host. A receiving practice may change
// this to its own name; nothing else in this tool depends on it. It names
// the FRAMEWORK, not the practice that shipped this seed: a recipient
// running an OKF-TOGAF tool is a true statement about them, and
// "WP-SEMINUM-01 activity 3" was not. Found in run 5 by a germinated
// practice's architecture role -- the only string in the seed that leaves
// a recipient's machine, and the one a four-brief disclosure review
// missed because it asked what the file DOES and not what it SAYS ABOUT US.
const USER_AGENT = 'okf-togaf-checkpoint-b/1.0';

say('CHECKPOINT B -- live headlines from an uncontrolled public feed');
say('');

if (!feed) {
  say(`REFUSE: unknown edition "${edition}". Known: ${Object.keys(FEEDS).join(', ')}`);
  process.exit(2);
}

// Only these three inputs may influence control flow. Never item text.
let status = null;
let body = null;
let failure = null;
const startedAt = new Date();

(async () => {
  try {
    const ctl = AbortSignal.timeout(15000);
    const res = await fetch(feed.url, {
      signal: ctl,
      headers: { 'user-agent': USER_AGENT },
    });
    status = res.status;
    body = await res.text();
  } catch (e) {
    failure = e.name === 'TimeoutError' ? 'timed out after 15s' : e.message;
  }

  say('  source    : ' + feed.label);
  say('  url       : ' + feed.url);
  say('  fetched   : ' + startedAt.toISOString());
  say('  credential: none -- one GET, one User-Agent header');
  say('');

  // --- Failure paths, each distinct and each loud ---
  if (failure !== null) {
    say('FAIL -- NETWORK. The request did not complete: ' + failure);
    say('');
    say('  This is the honest outcome, not a defect to be retried away.');
    say('  The practice reached for something it does not control and');
    say('  did not get it. No caching, no retry, by design (RULE-10 #4).');
    process.exitCode = 1;
    return;
  }

  if (status !== 200) {
    say(`FAIL -- HTTP ${status}. The service answered, but not with a feed.`);
    say('  Rate limit, geo restriction and retirement all look like this.');
    process.exitCode = 1;
    return;
  }

  const items = [...String(body).matchAll(/<item>([\s\S]*?)<\/item>/g)].map((m) => m[1]);

  if (items.length === 0) {
    say('FAIL -- 200 BUT ZERO ITEMS.');
    say('');
    say('  THIS IS THE FAILURE THAT LOOKS LIKE SUCCESS, and the reason it');
    say('  is checked separately. The geo/ endpoint tested during this');
    say('  build returns exactly this: a healthy 200 carrying no news at');
    say('  all. A checkpoint that printed an empty list here would report');
    say('  a dead feed as a quiet pass.');
    process.exitCode = 1;
    return;
  }

  // --- Extract. Nothing below influences control flow. ---
  const clean = (s) =>
    String(s)
      .replace(/<!\[CDATA\[|\]\]>/g, '')
      .replace(/&lt;/g, '<').replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&')
      // Strip control characters: third-party text is not allowed to
      // rewrite the terminal around itself.
      .replace(/[\x00-\x1f\x7f]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();

  const headlines = items.slice(0, limit).map((b) => {
    const t = b.match(/<title>([\s\S]*?)<\/title>/);
    const d = b.match(/<pubDate>([\s\S]*?)<\/pubDate>/);
    return { title: clean(t ? t[1] : '(no title element)'), pub: clean(d ? d[1] : '') };
  });

  say(`PASS -- ${items.length} items in the feed; showing ${headlines.length}.`);
  say('');
  headlines.forEach((h, i) => {
    const n = String(i + 1).padStart(2, ' ');
    const shown = h.title.length > 100 ? h.title.slice(0, 99) + '…' : h.title;
    say(`  ${n}. ${shown}`);
    if (h.pub) say(`      ${h.pub}`);
  });

  say('');
  say('  The lines above are third-party text. They were displayed and');
  say('  nothing else -- not executed, not evaluated, not used to decide');
  say('  anything. The only inputs to this run\'s control flow were the');
  say('  HTTP status, the item count, and the clock.');
  say('');
  say('CHECKPOINT B: PASS. The practice reached a service it does not');
  say('control, got a real answer, and neither trusted nor obeyed it.');
  process.exitCode = 0;
})();
