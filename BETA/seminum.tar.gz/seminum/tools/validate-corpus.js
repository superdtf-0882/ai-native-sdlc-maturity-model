#!/usr/bin/env node
// EA OKF v1.5 corpus validator.
//
// Checks, against a three-namespace ID universe (corpus row items,
// corpus sheet-level frontmatter IDs, spec-document frontmatter
// IDs -- Assertion Rule 5): parse cleanliness, the dangling-reference
// sweep, and architecture_contract type-index enforcement (realizes +
// ac_governing_refs: required, non-empty, all resolving -- P-10).
//
// Usage: node tools/validate-corpus.js   (run from anywhere; paths
// are resolved relative to this file, i.e. the repo root's parent)
//
// Exit code 0 = clean (no parse errors, no ill-formed contracts).
// Exit code 1 = at least one parse error or ill-formed contract.
// Dangling references do NOT affect exit code (informational --
// some may be pre-existing and tracked separately) but are always
// printed; a clean corpus prints "Dangling references: 0".
//
// ID COLLISIONS likewise do not affect exit code, and that is a
// deliberate choice rather than an oversight (OKF-TOGAF#52). Seven
// exist today (OI-050), so exiting non-zero would fail every commit
// through the pre-commit gate and force an unrelated governance
// decision under time pressure. A check that halts all work until
// someone renames a design-token series is a worse tool than one that
// reports. No expected-count baseline either -- a recorded "7" goes
// stale the moment OI-050 is resolved, which is the defect class this
// arc keeps logging.
//
// What the collision report DOES change: the "Dangling references"
// line now qualifies itself when the id space is ambiguous, so the
// number stops reading as a clean bill of health without its value
// changing.
//
// Parsing itself lives in tools/lib/corpus-parser.js -- the shared
// parse core Vellum also consumes (WP-STRATUM-01 activity 1, one
// parser not two). This file is reporting logic only.
const fs = require('fs');
const path = require('path');
const yaml = require('js-yaml');
const { parseCorpus, ambiguousRefs, seedFor, seedCensus, SEED_VALUES, SEED_DEFAULT } = require('./lib/corpus-parser');

const ROOT = path.join(__dirname, '..');
const { allIds, refs, contracts, parseErrors, files, collisions } = parseCorpus(ROOT, yaml);

let totalItems = 0;
const perFileCounts = {};
for (const f of files) {
  if (f.namespace !== 'sheet') continue;
  if (!f.front) continue; // no frontmatter (e.g. corpus/README.md pre-typing) -- not a counted sheet
  perFileCounts[f.file] = f.items.length;
  totalItems += f.items.length;
}

// Type-index enforcement (P-10: intent is typed, not tracked)
const contractFailures = [];
const resolutionTable = [];
for (const { item, file } of contracts) {
  const problems = [];
  if (!item.realizes || String(item.realizes).trim() === '') problems.push('realizes missing/empty');
  else {
    const ok = allIds.has(item.realizes);
    resolutionTable.push({ contract: item.id, field: 'realizes', ref: item.realizes, resolves: ok, where: allIds.get(item.realizes) || '-' });
    if (!ok) problems.push(`realizes -> ${item.realizes} does not resolve`);
  }
  if (!Array.isArray(item.ac_governing_refs) || item.ac_governing_refs.length === 0) problems.push('ac_governing_refs missing/empty');
  else for (const ref of item.ac_governing_refs) {
    const ok = allIds.has(ref);
    resolutionTable.push({ contract: item.id, field: 'ac_governing_refs', ref, resolves: ok, where: allIds.get(ref) || '-' });
    if (!ok) problems.push(`ac_governing_refs -> ${ref} does not resolve`);
  }
  if (problems.length) contractFailures.push({ id: item.id, file, problems });
}

const dangling = refs.filter(r => !allIds.has(r.to));

console.log('=== EA OKF v1.7 corpus validation ===');
console.log('Parse errors:', parseErrors.length); parseErrors.forEach(e => console.log('  -', e));
console.log('ID universe:', allIds.size, '(corpus items + sheet IDs + spec-doc IDs)');
console.log('Corpus items total:', totalItems);
console.log('Per-file counts:', JSON.stringify(perFileCounts));
console.log('related[] edges checked:', refs.length);
console.log('Dangling references:', dangling.length);
dangling.forEach(d => console.log('  -', d.file, ':', d.from, '->', d.to));

// The dangling count qualifies itself when the id space is ambiguous.
// Added 2026-08-14 (OKF-TOGAF#52) because "Dangling references: 0" is
// the number this practice cites most and it was green for the DS-*
// collisions BY COLLISION rather than by correctness: an edge naming a
// shadowed id does not dangle, because the wrong thing answers.
if (collisions.size) {
  const ambiguous = ambiguousRefs(refs, collisions);
  console.log('  ^ NOT a clean bill of health --', collisions.size,
    'colliding id(s);', ambiguous.length, 'edge(s) resolve ambiguously.');
  console.log('  ID COLLISIONS (same id declared in more than one place):');
  for (const [id, sites] of collisions) console.log('  -', id, ':', sites.join('  +  '));
  console.log('  An edge naming a colliding id resolves to whichever declaration');
  console.log('  won the overwrite, which may not be the one its author meant.');
  console.log('  Informational -- does NOT affect exit code.');
}
// --- seed eligibility (EA OKF v1.8, EXT-008) ---------------------------
//
// Two checks, and only two. A value outside the vocabulary is an error
// because it means the author intended something the field cannot say. A
// sheet-level `pattern`/`template` is an error because ONE header line
// makes every item under it shippable -- the failure fail-closed does not
// cover.
//
// Deliberately NO warning for undeclared items. Every item is undeclared
// on the day this ships; warning would put 300+ lines in this output and
// train everyone to stop reading it. Coverage is a query, not a build
// failure -- `seedCensus` answers it.
const seedErrors = [];
for (const f of files) {
  const sheetSeed = f.front && f.front.seed;
  if (sheetSeed !== undefined) {
    if (typeof sheetSeed !== 'string' || !SEED_VALUES.includes(sheetSeed)) {
      seedErrors.push(`${f.file}: sheet seed ${JSON.stringify(sheetSeed)} is not one of ${SEED_VALUES.join(' | ')}`);
    }
    // NO ITEM-COUNT RESTRICTION. All three values are legal at sheet
    // level on any file, since EA OKF v1.12 (2026-08-15, "I ratify §2,
    // §3 and the census fix - David Facer", DT's 09-DT-brief.md §3).
    //
    // WHAT WAS HERE AND WHY IT IS GONE, recorded rather than deleted.
    // v1.8 barred any sheet value but `instance`; v1.9 narrowed that to
    // files declaring items (issue #62, OI-058). Its hazard was real
    // under the old semantics -- a sheet-level `pattern` shipped every
    // item beneath the header, 45 items from five lines, one of them
    // `C-005`, which names a live production credential store.
    //
    // v1.12 RETARGETED THE RUNG: a sheet-level `seed` now declares the
    // sheet's own frontmatter and CANNOT REACH AN ITEM (see seedFor in
    // lib/corpus-parser.js, and the demonstration in this file's own
    // test run). The restriction became a prohibition on a mechanism
    // that no longer exists, so it is RETIRED rather than relaxed --
    // the distinction matters, because relaxing implies the hazard was
    // re-priced and it was not: it was removed.
  }
  for (const item of f.items || []) {
    if (item.seed === undefined) continue;
    if (typeof item.seed !== 'string' || !SEED_VALUES.includes(item.seed)) {
      seedErrors.push(`${f.file}: ${item.id} seed ${JSON.stringify(item.seed)} is not one of ${SEED_VALUES.join(' | ')}`);
    }
  }
}
// --- stratum agreement (issue #55) -------------------------------------
//
// Runs here so it fires on every commit and in CI, rather than being a
// library function nobody calls. checkAgreement covers both halves:
// the eight derived ID prefixes, and the 26 transcribed provenances.
// checkDeclared reconciles any item-level `stratum` that claims a
// LOCATION -- currently none, framework_entry being a subject reference
// and excluded by type.
//
// INFORMATIONAL, NOT FATAL, and deliberately so. Drift here means a
// transcription and SPEC-STRATA have parted company; it does not mean
// the corpus is malformed. Failing the build on it would fail every
// commit until someone reconciled a spec edit, which is how a check
// gets routed around. The same reasoning OI-050's collision report
// carries.
{
  const si = require('./lib/stratum-index');
  // NOT normalised, and safe only because stratum-index.js:70 splits on
  // /\r?\n/ -- i.e. safe by its CONSUMER's choice, not by this read's.
  // Left as-is deliberately (2026-08-18, issue below): changing it would
  // imply this codebase normalises at read, and it does not. If any future
  // consumer of specText matches a bare \n, this line is the next
  // seed-runtime.js:38. See briefs/2026-08-17-status-vocabulary/17-.
  const specText = fs.readFileSync(path.join(ROOT, 'spec', 'strata-and-intent-fibering.md'), 'utf8');
  const agree = si.checkAgreement(specText);
  const decl = si.checkDeclared(files, si.buildIndex(specText));
  console.log('--- stratum agreement ---');
  console.log(`Derived prefixes + transcribed provenances checked: ${agree.checked} (${agree.provenanceChecked} provenances). Declared locations: ${decl.checked}.`);
  const all = [...agree.problems, ...decl.problems];
  if (all.length) {
    console.log(`STRATUM DRIFT: ${all.length} -- informational, does NOT affect exit code.`);
    all.forEach((p) => console.log('  -', p));
  }
}

console.log('--- seed eligibility (EXT-008) ---');
const census = seedCensus(files);
const declared = census.filter(r => r.source !== 'default');
const shippable = census.filter(r => r.value !== SEED_DEFAULT);
console.log(`Items: ${census.length} -- ${declared.length} declared, ${census.length - declared.length} defaulted to "${SEED_DEFAULT}".`);
console.log(`Seed-eligible (pattern|template): ${shippable.length}.`);
if (seedErrors.length) {
  console.log('SEED ERRORS:', seedErrors.length);
  seedErrors.forEach(e => console.log('  -', e));
}
// --- seed runtime closure (OI-060, EA OKF v1.14) -----------------------
// Asserts SPEC-BUNDLE's seed_runtime declaration and computes the
// transitive require-closure over its entry points. This is what makes
// the convention a control rather than a note: it fails the build here,
// in this repo, today, long before any packager exists.
const { checkSeedRuntime } = require('./lib/seed-runtime');
const sr = checkSeedRuntime(ROOT, yaml);
console.log('--- seed runtime closure ---');
if (sr.closure) {
  console.log(`Entry points: ${sr.decl.entryPoints.join(', ')}`);
  console.log(`Closure: ${sr.closure.files.length} files, ${Math.round(sr.closure.bytes / 1024)} KB` +
    ` -- external: ${sr.closure.external.join(', ') || 'none'}` +
    ` -- outside tools/: ${sr.closure.outside.length ? sr.closure.outside.join('; ') : 'no'}`);
  sr.closure.files.forEach((f) => console.log('  ' + f));
}
if (sr.errors.length) {
  console.log('SEED RUNTIME ERRORS:', sr.errors.length);
  sr.errors.forEach((e) => console.log('  -', e));
}

console.log('--- architecture_contract type-index check ---');
console.log('Contracts found:', contracts.map(c => c.item.id).join(', ') || 'none');
if (contractFailures.length) {
  console.log('ILL-FORMED CONTRACTS:', contractFailures.length);
  contractFailures.forEach(c => console.log('  -', c.id, ':', c.problems.join('; ')));
} else if (contracts.length) {
  console.log('All contracts well-formed (type indices present, non-empty, resolving).');
}
console.log('--- resolution table ---');
resolutionTable.forEach(r => console.log(`  ${r.contract} ${r.field}: ${r.ref} -> ${r.resolves ? 'RESOLVES' : 'FAILS'} (${r.where})`));
process.exitCode = (contractFailures.length || parseErrors.length || seedErrors.length || sr.errors.length) ? 1 : 0;
