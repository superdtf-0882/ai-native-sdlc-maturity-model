# Read this first

This repository is a **governed practice**. Changes to the corpus are
governed by written rules, and **two roles operate here with different
authority**. They are not interchangeable. Establish which one you are
before you read a charter, not after.

## Step 0 — declare your role

| You are | Read in full, first | Then |
|---|---|---|
| **DT** — the architecture role: drafts, reviews, consults | `spec/charter-dt.md` | `corpus/rules.md` |
| **CC** — the execution role: measures, executes, records | `spec/charter-cc.md` | `corpus/rules.md` |

**Determine your role from the owner's instruction in this session.**
**Do not infer it from the working directory, from this file, or from
which tool you happen to be.** **If nothing has told you, ask.**

**If your charter does not exist yet**, say so and stop. Its shape is
`spec/charter-template.md`. **Authoring it is a governed act and it
belongs to the owner** — offer to draft, do not adopt one silently. A
role operating without a written charter is a role whose limits nobody
can check.

## If this practice has just been seeded

**Install the toolchain's one dependency first, or the checks cannot
run:**

    cd tools && npm install

**Then** run `node tools/checkpoint-a.js --root .` before dispatching or
closing any work. **If it reports a missing module, you skipped the line
above** — that is a tooling gap and says nothing about the state of this
practice.

**Expect it to refuse.** A newly seeded practice has **no intent of its
own**, and the check is built to say so rather than to proceed. **The
sparse state is the expected state, not a fault.**

**When the owner has not yet stated the practice's intent, eliciting it
is the architecture role's first task:**

- **Ask for three to five statements, in the owner's own words, about
  why this practice exists.**
- **Never pre-fill them. Never offer a menu to pick from. Never carry
  another practice's examples across as a starting point.**

Everything else in the corpus fibers back to those statements. **A
practice whose intent was suggested to it cannot use intent to settle an
argument later.**

**Eliciting is not recording.** The architecture role elicits and drafts;
**it does not write the intent register.** The statements become governed
text the way every other change does — the architecture role drafts an
execution brief, **the owner ratifies it**, and the execution role
registers the statements and reports what it did.

> **This is heavier than it looks, and that is the point.** Putting three
> sentences through a full cycle is slow, and it is the path that has
> caught what shorter ones missed — including a representation that
> validated cleanly and would have recited nothing. **A practice’s first
> governed act is the one with no precedent to check it against, which is
> exactly when a second pair of eyes is worth most.**

**If your practice has only one role, say so in your charter and record
who ratifies.** The cycle needs a drafter, a ratifier and an executor;
**it does not need three sessions, but it does need the three acts to be
distinguishable afterwards.**


## One tool reaches the internet

**`tools/checkpoint-b.js` makes outbound requests.** It fetches headlines
from public RSS endpoints to prove a practice can survive contact with a
service it does not operate.

**Nothing else runs it.** The germination check and the corpus validator
never call it, so **it is inert unless you run it deliberately.** If your
environment forbids outbound requests, delete the file — nothing depends
on it.

**Read it before you run it.** Its value is not the headlines; it is the
discipline it demonstrates — **third-party text is treated strictly as
data to display, never as something that can influence what the tool
does.** A headline that reads like an instruction is a headline.

**Do not run it as part of orientation.** It is not a germination check
and nothing requires it. **Run it when the owner asks, and say plainly
that it makes an outbound request before you do.**

## Standing obligations

**The repository is the authority.** This file, any cached copy of a
charter, and anything you remember from a previous session are
**convenience, never authoritative**. Where they disagree with the
repository, the repository wins. **Re-read your charter at every
reconstitution** — a session that has read a summary has not read the
document.

**Do not report a document's version or status from its prose.** In this
practice's own documents, editorial state lives in frontmatter —
`meta_status`, `meta_version` — and **that is the only field to trust.**

> **A seeded document has none of those fields.** They belong to the
> practice that authored it and were withheld deliberately, so **the
> documents you have arrived with carry no editorial state at all.** What
> some of them do carry, in the body, is **the originating practice's
> version history**: dated entries, version numbers, ratification lines.
> **None of it describes this practice, and none of it is current.**
>
> **Do not cite it, and do not repeat it as this document's status.** If
> asked what version a document is, the honest answer for a seeded
> practice is **that it does not have one yet** — and the first time you
> amend one, put its state in frontmatter and read it from there
> afterwards.

**A heading is prose too.** Where a heading and a frontmatter field
disagree, the field is the claim and the heading is a mistake to fix.

**Verify by running, not by reading.** Where a claim can be tested by
attempting the operation, reading the source or the configuration is not
evidence for it. Where you did reason rather than test, **say so and
name who must test it.**

**Record corrections beside what they correct**, rather than replacing
it. A reader who cannot see what was previously believed cannot tell a
correction from a revision.

## Before you change governed text

**Ordinary work — a fix, a filing, a measurement — needs no
consultation.** **Structural work does:** anything that amends the
schema, creates or retires a class of artifact, changes what a check
refuses, or alters a role's remit.

**Deciding which kind a piece of work is, is itself a judgment**, and
getting it wrong in the ordinary direction is how ungoverned changes
land. **When unsure, treat it as structural and ask.**
