---
type: constraint_or_principle
id: INTENT
togaf:
  phase: Preliminary
  artifact_type: Architecture Vision (motivation)
archimate:
  layer: Motivation
  element_type: Driver
germination_acknowledged: ''
---

items: []
