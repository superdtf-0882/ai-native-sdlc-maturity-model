---
type: constraint_or_principle
id: SHEET-12
togaf:
  phase: Phase B
  artifact_type: Constraints Catalog
archimate:
  layer: Motivation
  element_type: Constraint
catalog_category: Constraint
---

items:
  - id: C-003
    title: 'Autonomy Scale: Commander / Navigator / Autopilot'
    cp_kind: Constraint
    cp_statement: Canonical autonomy scale is Commander / Navigator / Autopilot. 'Copilot' rejected — Microsoft brand contamination.
    cp_source: Taxonomy design
    cp_scope: AI Taxonomy app, any taxonomy work, all UI and API responses referencing autonomy.
    cp_implications:
      - All UI, .md output, and API responses must use canonical scale.
    archimate:
      layer: Motivation
      element_type: Constraint
