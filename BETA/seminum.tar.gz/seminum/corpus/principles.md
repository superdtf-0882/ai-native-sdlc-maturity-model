---
type: constraint_or_principle
id: PRINCIPLES
togaf:
  phase: Phase A/H
  artifact_type: Architecture Principles Catalog
archimate:
  layer: Motivation
  element_type: Principle
catalog_category: Principle
---

items:
  - id: P-04
    title: Architecture Governance Before Implementation
    cp_kind: Principle
    cp_statement: CC proposes architecture; David approves before implementation begins. No work package may proceed to implementation without explicit architecture approval.
    cp_scope: All work packages in the platform migration and future initiatives.
    cp_implications:
      - WP2b and WP2c required David's DNS creation and architecture approval as explicit prerequisites.
      - WP3 required OPENAI_API_KEY configuration and prompt approval as deployment gates.
    archimate:
      layer: Motivation
      element_type: Principle
  - id: P-06
    title: Implementation Findings as Architecture Inputs
    cp_kind: Principle
    cp_statement: Production incidents and verification gaps shall be captured as constraints, ABBs, and principles — not just fixed and forgotten. Every incident is an architecture input.
    cp_scope: All work packages and post-deployment verification activities.
    cp_implications:
      - WP2a www redirect bug → ABB-002.
      - WP2b Redis production touch → C-005, ABB-001.
      - WP2c zero-env-var incident → OI-032, Pre-Deployment Checklist.
      - dinotherapy Blob store decision → ADR-005, Storage Governance Principle.
    archimate:
      layer: Motivation
      element_type: Principle
  - id: P-09
    title: The corpus governs; everything else evidences
    status: Active
    cp_kind: Principle
    cp_statement: 'Exactly one class of artifact governs the practice: schema-conformant corpus entries, subject to reconstitution testing and relationship gates. All other records — workbooks, briefs, application data, derived documents — are evidence: kept verbatim where valuable, cheap to retain, indexed from the corpus by reference, and never load-bearing for governance. Anything in an evidence artifact that must bind future work is promoted into the corpus explicitly.'
    cp_source: 'Generalized 2026-07-15 from three boundary decisions: workbook vs. corpus (deprecation sync), application data vs. corpus (ADR-007 Option B rejection), briefs vs. corpus (briefs SOP).'
    cp_implications:
      - Evidence stores carry no YAML/schema burden and are excluded from reconstitution tests.
      - The corpus references evidence (briefs:, resource fields); evidence never references forward as authority.
      - Agreements existing only in briefs or conversation govern nothing until promoted (see briefs/README.md).
    archimate:
      layer: Motivation
      element_type: Principle
  - id: P-10
    title: Intent is typed, not tracked
    status: Active
    cp_kind: Principle
    cp_statement: |
      Governed artifacts carry their intent index as a validity condition: the realizes/governing-refs fiber is required and resolution-validated at construction, not audited afterward. Conformance to intent is a construction property where structure can enforce it (type indices, three-namespace resolution) and a judgment gate where it cannot (issuance, sign-off, ratification). Unreferenced intent is unrepresentable; misreferenced intent is caught by humans.
    cp_source: |
      Intent-fibering session 2026-07-16 (SPEC-STRATA); implemented in EA OKF v1.5 type indices before being stated — promoted 2026-07-17 so the corpus declares what it enforces.
    cp_implications:
      - New governed artifact classes get type indices at design time, not audit rules later.
      - The transitive S0-termination check (WP-D6-04) completes what parse-time typing begins.
    archimate:
      layer: Motivation
      element_type: Principle
    related:
      - id: P-09
        relationship: related_to
  - id: P-11
    title: Ordinal Maturity Dimensions Are Never Averaged
    status: Active
    cp_kind: Principle
    cp_statement: Per-dimension maturity grades (Pre-AI, A-E, Exempt) are ordinal judgments, not interval-scale numbers. They are never averaged, summed, or otherwise collapsed into a single computed statistic -- for scoring, display, tooling, or AI interpretation purposes. Each dimension is independently meaningful; only the per-dimension profile is authoritative. An overall grade, where a model's own documentation mentions one, is a directional summary only, never a computed statistic. Non-averaging summaries of the profile -- a distribution count (e.g. '8 of 13 dimensions at C or higher'), a modal level, or similar -- remain legitimate; only collapsing the grades into a single arithmetic mean or sum is prohibited, since that specifically assigns false numeric precision the ordinal scale does not support.
    cp_source: 'Generalized 2026-07-28 from a live bug David found in aimaturitymodels.com''s self-assessment tool -- a malformed nested-bold markdown span and a numeric average of ordinal A-E grades. Audited across every surface presenting or interpreting model scores (self-assessment tool, all three Executive Readout prompts, the Whole-Model View, the AI-readable digest); one real gap found, in the digest''s own Instruction #7. Proposed as P-11 in briefs/2026-07-28-no-averaging-principle/, ratified with three amendments in briefs/2026-07-28-p11-ordinal-averaging/ -- classification checked against this corpus''s own Constraint-vs-Principle pattern (concrete/technical/incident-sourced statements are Constraints; general enduring ''shall''-style rules spanning future decisions are Principles) rather than assumed; this rule matches the latter.'
    cp_implications:
      - aimaturitymodels.com's self-assessment tool computes no numeric average across dimensions; the per-dimension table is the authoritative result (already implemented, aimaturitymodels@d5de060/@bf02df8).
      - Executive Readout prompts must interpret the per-dimension profile holistically and must never reduce it to a single averaged or aggregate number (already true of all three current prompts -- verified, not assumed).
      - 'The AI-readable digest''s own Instruction #7 is widened from ''Do not average Exempt dimensions into aggregate maturity'' to a general prohibition on averaging any dimension -- Exempt or A-E -- into an aggregate (lib/aiDigestCore.js, this same pass).'
      - 'Any future scoring instrument computing or reporting an aggregate numeric score requires the same governed-exception discipline STD-SDLC-MM''s own Exempt designation already requires: a citable constraint_or_principle corpus ID as its authority, and a stated review_trigger (date or event) at which the exception is reconsidered -- not an informally-argued one-off, and not a second, lighter exception mechanism invented separately from Exempt''s own.'
    archimate:
      layer: Motivation
      element_type: Principle
