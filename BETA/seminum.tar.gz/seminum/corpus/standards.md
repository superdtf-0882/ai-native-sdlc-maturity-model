---
type: constraint_or_principle
id: STANDARDS
togaf:
  phase: Phase A/B
  artifact_type: Reference Standard
archimate:
  layer: Motivation
  element_type: Requirement
catalog_category: Standard
---

items:
  - id: STD-SDLC-MM
    title: AI-Native SDLC Maturity Model
    status: Active
    cp_kind: Constraint
    cp_statement: The practice's target standard for SDLC maturity. 13 dimensions (D1-D13), five levels (A-E) per dimension. Maturity assessments (MA-* items in compliance_reviews.md) are each locked to a specific version of this standard.
    cp_source: Published at github.com/superdtf-0882/ai-native-sdlc-maturity-model (CC BY 4.0, (c) 2026 David Facer). Practice work drives new versions; version bumps are recorded here as they publish.
    std_current_version: 'v1.1.0 -- released 2026-07-21 (annotated tag v1.1.0, HEAD 3bbdc60, GitHub Release https://github.com/superdtf-0882/ai-native-sdlc-maturity-model/releases/tag/v1.1.0). CLI-confirmed at both levels per Rule 7: tag SHA and release resolved via gh api this session; local clone at the same HEAD. Additive release under AC-002 (issued 2026-07-21, executed same day): Pre-AI threshold state (outside the A-E scale), Exempt designation (constraint-cited governed stance, excluded from aggregates, always rendered, reviewable), assessment schema additions (Pre-AI and Exempt(constraint-ref) legal values; readiness_note, review_trigger). All thirteen dimensions and all A-E level definitions unchanged from v1.0.0; the v1.0.0 tag is untouched and all prior assessments remain valid against it. Prior value of this field (the v1.0.0 lock detail) is preserved in this file''s git history.'
    std_repo: https://github.com/superdtf-0882/ai-native-sdlc-maturity-model (remote) / C:\Users\User\Documents\GitHub\ai-native-sdlc-maturity-model (local clone, in sync with remote as of the v1.0.0 lock, 2026-07-15)
    std_assessment_instrument: Assessments against this standard are produced by SPEC-D6-SCORE (spec/d6-scoring-instrument.md) from its first use (2026-07-19, WP-D6-04) -- instrument-scored MA-* items lock to both standard_version and instrument_version. MA-2026-07-19 is the assessment of record (David reviewed and accepted the first instrument run's divergences 2026-07-22, zero criteria amendments -- instrument v1.0 criteria stable; MA-2026-07-15 stands as the historical pre-instrument baseline).
  - id: STD-SHARED-INTELLIGENCE
    title: AI-Native Shared Intelligence Layer (D1-D3)
    status: Active
    cp_kind: Constraint
    cp_statement: The canonical definition of D1 (Market discovery & definition), D2 (Buyer/user persona development), and D3 (Positioning & competitive intelligence), inherited by reference by the AI-Native SDLC Maturity Model and the AI-Native PDLC Maturity Model. Five levels (A-E) per dimension, same shape as STD-SDLC-MM. Ratified 2026-07-23, superseding both models' own previously locally-maintained D1-D3 text.
    cp_source: Published at github.com/superdtf-0882/ai-native-sdlc-maturity-model as shared_intelligence_layer.md (CC BY 4.0, (c) 2026 David Facer) -- co-located with the SDLC model until the model family's own repo-per-model infrastructure (OI-040) opens and a dedicated home is warranted, per the same 'until family size warrants a stratum-tools repo' discipline already applied to sync tooling.
    std_current_version: 'v1.0.0 -- ratified 2026-07-23 (''I ratify the D1-D3 reconciliation -- David, 7/23/26''), released same day, tag v1.2.0 on ai-native-sdlc-maturity-model (HEAD 4730189). Reconciliation record: briefs/2026-07-23-d1-d3-reconciliation/01b-d1-d3-reconciliation-record.md -- a fifteen-cell, five-axis reconciliation between the predecessor D1-D3 text (locked in SDLC''s own v1.1.0) and the Shared Intelligence Layer candidate (first drafted 2026-07-22). Fourteen cells adopted unchanged or with clarification only; one real maturity-state revision (D2-B, ''ad hoc'' -> ''consistent AI-assisted method'', for coherence with D1-B/D3-B''s already-identical language at that letter). Provenance: reconciliation methodology/framing from a David-Craig conversation; the fifteen-cell analysis and disposition record is David Facer''s own direct work, not delegated.'
    std_repo: https://github.com/superdtf-0882/ai-native-sdlc-maturity-model/blob/main/shared_intelligence_layer.md (remote) / C:\Users\User\Documents\GitHub\ai-native-sdlc-maturity-model\shared_intelligence_layer.md (local clone)
    std_assessment_instrument: Not independently assessed -- D1-D3 assessments occur as part of whichever lifecycle model's own instrument scores them (SPEC-D6-SCORE for SDLC). This entry exists to lock which version of the shared D1-D3 text a given lifecycle assessment was scored against, the same purpose STD-SDLC-MM serves for D4-D13.
    notes: 'PDLC-side inheritance COMPLETE 2026-07-27 (WP-PDLC-01): the PDLC repo now exists (github.com/superdtf-0882/ai-native-pdlc-maturity-model, v1.0.0), and its own D1-D3 section is a direct reference to this document, not a local copy -- the gate this note originally described (OI-040) is satisfied for PDLC''s half. Prioritization''s own repo remains ungated-but-not-yet-created; not requested as part of this WP.'
    related:
      - id: STD-SDLC-MM
        relationship: related_to
  - id: STD-PDLC-MM
    title: AI-Native PDLC Maturity Model
    status: Active
    cp_kind: Constraint
    cp_statement: The practice's target standard for PDLC (Product Development Life Cycle / Product Management function) maturity. 12 dimensions (D1-D12), five levels (A-E) per dimension, same shape as STD-SDLC-MM. D1-D3 inherited from STD-SHARED-INTELLIGENCE; D4-D12 model-own content.
    cp_source: Published at github.com/superdtf-0882/ai-native-pdlc-maturity-model (CC BY 4.0, (c) 2026 David Facer). Content originates from David's own working draft (section 5 of the family's original brief, filed verbatim 2026-07-21), held pending the family vocabulary lock (2026-07-24) and OI-040's sequencing gate (satisfied 2026-07-27).
    std_current_version: 'v1.2.0 -- released 2026-07-28 (github.com/superdtf-0882/ai-native-pdlc-maturity-model/releases/tag/v1.2.0). v1.0.0 (2026-07-27) was the first locked baseline, with two corrections applied at lock beyond the underlying draft''s own content: vocabulary retrofit (Initial/Emerging/Structured/Integrated/Adaptive -> Nascent/Modeled/Continuous/Integral/Telemetric) and D1-D3 extraction to shared_intelligence_layer.md (replacing a locally-maintained copy that had diverged from the ratified canonical text). v1.1.0 (2026-07-28) added per-transition verification clauses across D4-D12 (36 clauses) -- no maturity-state content changed. v1.2.0 (2026-07-28) added deep_dives/ -- narrative Per-Dimension Deep-Dive essays for all 12 dimensions -- again no change to the matrix itself. Corrected 2026-07-28 -- this field had drifted to the stale v1.0.0 baseline through two real version bumps.'
    std_repo: https://github.com/superdtf-0882/ai-native-pdlc-maturity-model (remote) / C:\Users\User\Documents\GitHub\ai-native-pdlc-maturity-model (local clone)
    std_assessment_instrument: 'SPEC-D6-SCORE-PDLC (spec/d6-scoring-instrument-pdlc.md, v1.0, 2026-07-28), issue #19. Designed in one consolidated pass alongside SPEC-D6-SCORE-PRIORITIZATION, sharing SPEC-D6-SCORE''s own global scoring rules verbatim. D1-D3 criteria inherited by reference from SPEC-D6-SCORE''s own D1-D3 blocks; D4-D12 criteria distilled fresh, each citing that dimension''s own real Verification clause (ai_native_pdlc_maturity_model.md v1.1.0) as the level''s evidence test. No MA-* assessment yet produced against it -- the instrument exists, execution against a real organization is separate, future work.'
    notes: Registered same day the repo was created (WP-PDLC-01), not retroactively -- this entry and the repo's own existence land in the same governance motion.
    related:
      - id: STD-SHARED-INTELLIGENCE
        relationship: governed_by
  - id: STD-PRIORITIZATION-MM
    title: AI-Native Product Prioritization Maturity Model
    status: Active
    cp_kind: Constraint
    cp_statement: The practice's target standard for product prioritization maturity. 3 dimensions (D1-D3), five levels (A-E) per dimension, same shape as STD-SDLC-MM/STD-PDLC-MM. All three dimensions are this model's own content -- none inherited from STD-SHARED-INTELLIGENCE, confirmed by direct check, not assumed.
    cp_source: Published at github.com/superdtf-0882/ai-native-product-prioritization-maturity-model (CC BY 4.0, (c) 2026 David Facer). Content transcribed from David's own working draft workbook (AI_Native_Product_Prioritization_Maturity_Model_v1.0.xlsx, retained in the SDLC repo as historical evidence), which received its own vocabulary/S0-reference/attribution corrections 2026-07-26, prior to this repo's creation.
    std_current_version: v1.2.0 -- released 2026-07-28 (github.com/superdtf-0882/ai-native-product-prioritization-maturity-model/releases/tag/v1.2.0). v1.0.0 (2026-07-28) was the first locked baseline, no content changes beyond transcription from the workbook -- David's own 2026-07-26 ruling ('v1.0 stands, current') already confirmed the workbook's content itself, once the family vocabulary lock condition was met. v1.1.0 (2026-07-28) added per-transition verification clauses across D1-D3 (12 clauses). v1.1.1 (2026-07-28) fixed a genuine transcription bug -- every dimension's table header declared a phantom 'Dimension-specific state' column that no data row ever actually had -- header-label correction only, no maturity content affected. v1.2.0 (2026-07-28) added deep_dives/ -- narrative Per-Dimension Deep-Dive essays for all 3 dimensions -- no change to the matrix itself. Corrected 2026-07-28 -- this field had drifted to the stale v1.0.0 baseline through three real version bumps.
    std_repo: https://github.com/superdtf-0882/ai-native-product-prioritization-maturity-model (remote) / C:\Users\User\Documents\GitHub\ai-native-product-prioritization-maturity-model (local clone)
    std_assessment_instrument: 'SPEC-D6-SCORE-PRIORITIZATION (spec/d6-scoring-instrument-prioritization.md, v1.0, 2026-07-28), issue #26 -- a genuinely separate issue from #19 (PDLC''s own equivalent gap), not one design pass covering both as this note previously and incorrectly claimed (corrected 2026-07-28 after that mismatch was caught while filing #26). The two instruments were, however, designed together in one consolidated pass sharing SPEC-D6-SCORE''s own global scoring rules verbatim. All three dimension-criteria sets are authored fresh (none inherited, per this model''s own confirmed independence from STD-SHARED-INTELLIGENCE), each citing that dimension''s own real Verification clause (ai_native_product_prioritization_maturity_model.md v1.1.0) as the level''s evidence test. No MA-* assessment yet produced against it -- the instrument exists, execution against a real organization is separate, future work.'
    notes: Registered same day the repo was created (WP-PRIORITIZATION-01), not retroactively. Closes OI-040 -- this is the second and final model repo that open item's gate held behind.
