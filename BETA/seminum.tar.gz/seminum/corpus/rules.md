---
type: constraint_or_principle
id: SHEET-RULES
togaf:
  phase: Phase G
  artifact_type: Architecture Principles Catalog
archimate:
  layer: Motivation
  element_type: Constraint
---

items:
  - id: RULE-1
    title: Read before writing
    cp_kind: Rule
    cp_statement: |
      No brief may specify file-level YAML edits without the author having read the current content of each target file. If files are not in context, ask CC to paste current content before drafting edits.
    cp_scope: Corpus brief authoring
    cp_rationale: Briefs that specify file-level YAML edits must be drafted from the corpus, not derived from the workbook.
    archimate:
      layer: Motivation
      element_type: Constraint
  - id: RULE-2
    title: ID schemes are independent
    cp_kind: Rule
    cp_statement: |
      The Code Asset Inventory workbook (VP-XXX, DS-XXX, SF-XXX) and this corpus (A-XX, DS-XXX, OI-XXX, R-XXX, I-XXX) were built independently and do not share an ID scheme. Workbook IDs do not map directly to corpus IDs. Always trace from corpus content — never derive corpus IDs from workbook numbering.
    cp_scope: Corpus brief authoring
    archimate:
      layer: Motivation
      element_type: Constraint
  - id: RULE-3
    title: Commit in the same session
    cp_kind: Rule
    cp_statement: |
      Any file created in the corpus or spec directories must be committed before the session ends. Untracked files are not governed by P11 and are invisible to future sessions.
    cp_source: ADR-007 found untracked, 2026-07-14
    archimate:
      layer: Motivation
      element_type: Constraint
  - id: RULE-4
    title: State the verification class
    cp_kind: Rule
    cp_statement: |
      Every closure or confirmation states how it was verified: **CLI-confirmed** (checked directly by running the command, diffing the file, or requesting the URL), **reported action** (owner attestation for steps the executing role cannot see), or **schema-confirmed** (the file parses, the identifiers resolve). Never present a reported action as a confirmed check.
      **Where a claim can be tested by attempting the operation, reading the source or the configuration is not sufficient evidence for it.** Stating the class honestly is necessary and not sufficient: a correctly-labelled *read-derived* finding on a testable claim is an unfinished check, not a finished one with a caveat.
      **Where attempting the operation is barred** -- because it would perform an issuance, a write, or an irreversible act the role may not perform, or because the role’s own substrate denies the tool -- the claim is labelled **read-derived** *and* a party who can run it is **named on the verification note’s read-derived line**. An untested claim with nobody named is not discharged. No separate register tracks these; the verification note is the register.
      **A DATE NAMES THE ACT IT DATES.** A date in governed text names the act it dates and is taken from that act -- never from a containing folder, a sibling entry, or the previous version’s line. Landing dates come from the commit, which settles them. **This is an evidence rule**: it says what ESTABLISHES a date claim, which is what this Rule governs, and it belongs beside the verification classes because a ratification date has no class better than read-derived-with-named-owner and the owner is the only witness.
      **A folder name is not a timestamp.** Where a dated folder, a brief header and a governed line each inherit a date from the one above, a single wrong date propagates silently and uniformly -- which is why this class of error survives review passes that would catch a random one. **Ratification and landing are different acts by different parties**: a commit settles when something was published and says nothing about when it was ratified.
    cp_source: 'CR-011 closure, 2026-07-14. Method-preference clause added 2026-08-13 (briefs/2026-08-13-product-initiative/), ratified by David the same day ("David Facer 8-13-2026"), landed as FINAL text and never as Draft per the D3 rule for multi-item sheets. Origin: five defects found in dispatch-gate.js by RUNNING it, after two DT instances reasoned about the same tool in parallel and neither ran it. Two of the five -- a closed, delivered issue returning DISPATCH OK, and exit 2 reading as success to a caller testing for 1 -- required no adversary at all. The gap was never candour or vocabulary: every verification class was labelled correctly, and DT stated in the same brief that its last two read-derived flags had both proven real on the write side, then did not test. Nothing preferred one method over another when both were available. The principle already existed twice in this corpus -- RULE-5 substrate text ("verified by attempted operation rather than by configuration") and CR-023 review trigger ("a re-run of the enumeration test, not an inspection") -- and both times was bound to an artifact rather than to conduct. This is the inverse of the §3.8 failure: there a mechanism gap was answered with a rule, here a principle was discovered twice and never promoted. The fix landed at the wrong altitude both times. **Kept as an amendment rather than a separate Rule, on DT decision (04-DT-response.md A1):** split, the two become separately citable and a report could satisfy RULE-4 in full while leaving the method clause unmet -- the exact shape that failed, made formally defensible. Kept together, RULE-4 compliance cannot be claimed by labelling alone. DT also noted this rule has mixed disclosure and duty since CR-011: the closing sentence is already a prohibition on conduct. **The named-owner clause lands on the verification note existing read-derived line, and adds nothing else** (DT A2). DT diagnosis of the six clauses this practice wrote and did not execute: none failed for being too demanding, all failed for having nowhere to land. §3.7 verification note is the counter-example -- fixed location, checked, nonconforming if absent. No register and no sweep; a mechanism to watch the mechanism is the ceremony the sustainability finding warns about. **Standing consequence for DT, recorded rather than discovered.** Three of six tools in tools/ shell out to gh -- dispatch-gate.js, close-gate.js, type-issue.js -- and all three are denied in DT provisioned clone by CR-023 residual-hole mitigation. DT is therefore permanently barred from attempting the operation on the dispatch tool class, and every DT claim about it will be read-derived with CC named as owner. That is the escape hatch working as designed, not evasion. Stated once here so a reader of a future DT brief does not have to wonder.'
    archimate:
      layer: Motivation
      element_type: Constraint
  - id: RULE-5B
    title: Owner-placed files
    cp_kind: Rule
    cp_statement: |
      David may place files directly in the repo. Any such file is named in the next brief or exchange it relates to; CC records its provenance in the commit message when it lands. A file with no announcing exchange is an orphan: it stays uncommitted (Rule 3's commit obligation applies only to files whose story is known), is raised with David in the same session it is noticed, and if unresolved becomes an Open Item.
    cp_source: The rung (a) operator checklist, 2026-07-17, generalizing ADR-007 — the problem was never who moves files; it's files without a story.
    archimate:
      layer: Motivation
      element_type: Constraint
  - id: RULE-6
    title: Derived visuals
    cp_kind: Rule
    cp_statement: |
      Rendered diagrams (SVG, PNG, HTML visualizations) are derived artifacts, never sources of truth. They live in `docs/`, and each carries an annotation (SVG `<desc>`, HTML comment, or sidecar note) naming the corpus IDs it renders. PES-001 currency doctrine applies: a diagram depicting a superseded state is misinformation, not documentation debt — regenerate or remove when the underlying corpus items change. PDT-001 governs color semantics.
    cp_implications:
      - Extended 2026-08-01 to the aimaturitymodels.com AI-readable digest, which is a rendering of the same class -- see that artifact's own Provenance section.
    archimate:
      layer: Motivation
      element_type: Constraint
  - id: RULE-8
    title: Corpus by reference
    cp_kind: Rule
    cp_statement: |
      Briefs reference corpus elements by ID; CC retrieves current content from the live corpus before acting. Full-text embedding in briefs is optional convenience and never authoritative over the live corpus.
    cp_source: WP-D6-03, 2026-07-15
    cp_implications:
      - 'This rule is why the migration creating this file was necessary: until 2026-08-07 Rule 8 itself could not be referenced by ID.'
    archimate:
      layer: Motivation
      element_type: Constraint
  - id: RULE-9
    title: Consultation before structural execution
    cp_kind: Rule
    cp_statement: |
      Any work package that amends the schema or these Rules, creates or retires an artifact class, stratum, or governance mechanism, changes validator enforcement, or alters an agent's role or charter receives a consultation brief before its execution brief. A mixed work package classifies by its most structural element. Ordinary corpus work remains single-brief.
    cp_source: WP-D6-01, 2026-07-16 — executed without design consultation; CC's structural flags were design review performed too late. Adopted 2026-07-17 after the WP-RA-01 consultation — itself this rule's first observance.
    archimate:
      layer: Motivation
      element_type: Constraint
  - id: RULE-10
    title: State how a control can be crossed
    cp_kind: Rule
    cp_statement: |
      Any control this practice imposes states, **in its governed source of record**, either the paths by which it can be crossed or an explicit assertion that none exist. **A control whose source says neither is undeclared, not thereby closed.**
      **A control is an artifact that refuses.** It has an enforced refusal — a non-zero exit, a 403, a denied tool call, a withheld signature — or it is not a control and this rule does not reach it. An artifact that describes a control without imposing it cites the declaration rather than restating it (`RULE-8`).
      **A control refuses an *actor*, not an *input*.** Rejecting a malformed argument is defensive programming; preventing a party from doing something they could otherwise do is a control. A function that throws on a typo is not thereby in scope. Added 2026-08-14 on DT's own correction to the test it authored (`07-DT-response.md` §5), after `tools/lib/kanban.js` was classified as not-a-control for a stated reason that was wrong — its `setStatus` does throw, so the original wording reached it.
      The **governed source of record** is the version-controlled artifact whose change changes the control's behaviour. Where a control operates from a deployed copy, the copy inherits the declaration and does not carry its own — the same source/derived discipline as `RULE-6`. **A control with no governed source of record is itself a declarable defect:** give it one, or record in the nearest governing artifact that it has none.
      **The channel by which a control is installed, updated, or maintained is itself such a path**, and is declared with the rest.
      Each declared path names a citable corpus ID as its authority and the moment it is reconsidered, per the governed-exception discipline `P-11`'s implications already require of scoring exemptions.
      Nothing is prohibited by being declared. This rule bans **silent** crossings, not crossings — the same shape as `RULE-4`, which bans misstating a verification class rather than banning weak evidence. **No validator enforces this and none can:** an undeclared crossing has no oracle, since detecting one means already knowing it exists. Enforcement is a reader finding the statement absent.
    cp_source: 'Ratified 2026-08-13 ("David Facer 8-13-2026"), briefs/2026-08-13-fiat-formation/. Adopted from axiom A3 of Craig Johnson''s Fiat Formation proposal (OI-049) -- the one clause of that package CC''s independent read found worth taking, separated deliberately from the apparatus around it and restated in this practice''s own language. None of the proposal''s vocabulary is adopted. Promotes to conduct the governed-exception discipline P-11''s cp_implications already required of scoring exemptions -- the third principle in this arc found bound to an artifact rather than to conduct, after attempt-over-inspect was found bound twice (RULE-5''s substrate text, CR-023''s review trigger) and promoted into RULE-4 the same morning. Occasioned by the TC-19 maintenance channel: the hook enforcing DT''s write boundary is deployed by shell cp, the one channel it cannot observe -- a real crossing, found by accident while drafting OI-048. **The argument that carried it is a table row, not a claim:** dispatch-gate.js declares its own limits and close-gate.js does not, though they are the same tool class by the same author in the same week; the only difference is what CC happened to be thinking about that morning. The rule does not introduce a discipline, it makes an existing instinct reliable. **Four DT decisions are in this text and three changed it** (04-DT-response.md): the declaration lands in the GOVERNED SOURCE OF RECORD rather than CC''s draft wording ''the artifact that imposes it'', which was ambiguous for the very control that motivated the rule and would have placed the declaration in a deployed copy the corpus cannot see drift -- DT resolved it by reusing RULE-6''s existing source/derived discipline; the scope test is now ''an artifact that refuses'', which is checkable by someone who has never seen the artifact, where CC''s ''purpose is to prevent'' leaked into prescriptive specs; and the no-governed-source case was added as a declarable defect after DT found two controls in that state (remote.origin.pushurl=no-push and .git/hooks/pre-push in the DT clone, both refusing, neither under version control). DT also enumerated the twelfth-rule cost CC had only estimated -- nine live references across four files, repointed in this same motion, with two changelog lines deliberately untouched per CHARTER-DT 3.4. **DT ran D4''s sweep rather than reasoning about it:** every cp_implications entry in principles.md and constraints.md, returning two candidates and no fourth instance of the wrong-altitude class, which settles that the class is a true description of three past events and not a live backlog. All three were found while working on something adjacent, never by searching -- so the response is asking the altitude question at authoring time, which is what this rule institutionalizes. RULE-10 is an instance of the fix for the pattern it names.'
    cp_implications:
      - close-gate.js received its own crossings declaration as this ratification's first act -- the defect the proposing brief found by pricing itself, closed before the rule requiring it was a day old.
      - 'DT-CLONE.md is NOT a control under the refuses test and carries no declaration of its own; it documents controls and cites theirs. P-09 is likewise not a control: it states where governing authority lives, and nothing refuses -- it can be misapplied but not crossed.'
    archimate:
      layer: Motivation
      element_type: Constraint
