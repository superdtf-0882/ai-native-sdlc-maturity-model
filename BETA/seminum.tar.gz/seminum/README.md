# A governed architecture practice

This repository holds an **architecture corpus** — the decisions,
principles, rules and open questions of a practice — together with the
tools that check it and the rules that govern changing it.

**It was seeded from a portable package, and it is nearly empty on
purpose.** What it carries is *shape*: the file formats, the schema, a
worked example, and a small number of rules that are true of any
practice. **What it does not carry is your practice.** Nobody else can
write that part.

## Start in an empty repository

This package assumes it is arriving somewhere with no prior history.
**Dropping it into a repository that already contains a practice — or any
prior commits — will not be detected**: the germination check reads the
corpus, not the git history, so **a tree can pass every signal while its
remote holds someone else’s work.** The collision surfaces on your first
push, after you have already authored your intent.

**If you must seed into an existing repository, check the remote before
your first push rather than after.**

## Start here

**1. Install the one dependency.**

    cd tools && npm install js-yaml

**2. Check that the corpus parses.**

    node tools/validate-corpus.js

Exit 0 means every file is well-formed and every cross-reference
resolves.

**3. Check whether the practice has germinated.**

    node tools/checkpoint-a.js --root .

On a freshly seeded repository this reports **germination mode** and
**refuses to go further**. That refusal is the tool working. It is
telling you that the practice has no stated intent yet, and that
**intent is yours to author** — no tool will invent one for you.

## Working with an AI agent

This practice is designed to be operated by a human owner and one or
more AI agents, with the boundary between them written down rather than
assumed.

**Before an agent does anything here, it must know which role it is.**
See `CLAUDE.md` in this directory — an agent should read it first, and
you should point your agent at it explicitly if your tooling does not
load it automatically.


## One tool reaches the internet

**`tools/checkpoint-b.js` makes outbound requests.** It fetches headlines
from public RSS endpoints to prove a practice can survive contact with a
service it does not operate.

**Nothing else runs it.** The germination check and the corpus validator
never call it, so **it is inert unless you run it deliberately.** If your
environment forbids outbound requests, delete the file — nothing depends
on it.

**Read it before you run it.** Its value is not the headlines; it is the
discipline it demonstrates — **third-party text is treated strictly as
data to display, never as something that can influence what the tool
does.** A headline that reads like an instruction is a headline.

## What is here

| | |
|---|---|
| `corpus/` | the governed record — principles, rules, constraints, standards, intent |
| `spec/` | the schema the corpus is written against, and reference documents |
| `tools/` | the checks: a parser, a validator, and a germination check |
| `MANIFEST.md` | what the seed package contained, and how much of the source it represents |

## What is deliberately absent

**Your intent.** The corpus's intent register is empty. It is the first
thing to write and everything else fibers back to it.

**Your role charters.** `spec/charter-template.md` is their shape. A
practice with two governed roles writes two charters; one role, one
charter. **The number of charters is the number of roles that can act on
the corpus.**

**The originating practice's content.** The seed carries what transfers
and withholds what does not. `MANIFEST.md` states how much was withheld,
by count. **A thin sheet here is a deliberate subset, not a failed
build.**

## The one habit worth adopting immediately

**Record the reason on the artifact, not in the conversation.** A
decision whose reasoning lives only in a chat log cannot be reviewed,
cannot be corrected, and will be re-litigated by the next person — or
by the next session of the same agent.
