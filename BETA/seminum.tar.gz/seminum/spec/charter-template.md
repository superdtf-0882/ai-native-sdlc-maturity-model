---
type: constraint_or_principle
id: SPEC-CHARTER-TEMPLATE
title: Role Charter — Template
togaf:
  phase: Preliminary
  artifact_type: Architecture Governance Framework
archimate:
  layer: Business
  element_type: BusinessRole
---

# Role Charter — Template

**This is a template. It ships with its shape and none of the
originating practice's content.** Copy it once per governed role, fill
every section, and delete this paragraph.

**A role charter states what a role is, what it may do, what it must do,
and how a fresh session of it rebuilds itself.** A practice with two
governed roles has two charters. A practice with one has one. **The
number of charters is the number of roles that can act on the corpus.**

## 0. Bootstrap kernel

**The section a session reads first, before it does anything else.** It
establishes which role the session is, and refuses to proceed if that is
undetermined.

**State here:**
- **How the role is declared.** A session must not infer its role from
  its working directory, its tooling, or the fact that it can write. **If
  nothing declares it, the session asks.**
- **What to read, in order**, to become oriented — this charter, then
  the Rules, then what the task needs.
- **A germination check.** If the corpus is newly seeded — no intent
  authored, no work items active, no exchange history — **say so and
  refuse to dispatch or close work until the practice's own intent
  exists.** A seeded practice has no S0 by construction; that is the
  expected state, not a fault, and **the correct response is to refuse
  and explain rather than to proceed silently or fail cryptically.**

**Keep this section cacheable and keep it short.** It is the only part a
session may reasonably hold outside the repository, and **the repository
is always authoritative over any cached copy.**

## 1. Identity and stratum

**State who this role is and where it sits** in the practice's own
stratum model.

**A role is not a person and not a tool.** It is a set of permissions and
obligations that any session adopting the role inherits entire.

## 2. Authority and its boundary

**The substance of a charter is what the role may not do.**

**State:**
- **What the role may decide alone.**
- **What it may draft but never issue**, and who issues it.
- **What it may never do**, in any circumstance.
- **How each boundary can be crossed** — the paths, or an explicit
  statement that none exist. **A boundary whose text says neither is
  undeclared, not thereby closed.**

**Where a boundary is enforced by something outside this document — a
credential, a hook, a permission — say so, and say what it does not
cover.** An enforced boundary and a stated one are different claims and
should not read alike.

## 3. Obligations

**Each obligation states the failure it exists to prevent.**

**An obligation invented in the abstract will be followed until it is
inconvenient. One that names the incident it came from survives**, and a
later reader can judge whether the circumstances still hold.

**Include, at minimum:**
- **What the role must verify rather than assume**, and by what method.
- **What it must record**, and where.
- **What it must disclose** — including its own errors, before they are
  found.
- **How it treats prior conversation, cached text, and its own memory:
  as claims to re-check, never as sources.**

## 4. Working relationships

**State how this role interacts with each other role and with the
practice's owner** — what it hands over, what it receives, and what it
must not accept as authority.

**Where an instruction can reach this role only through another role,
say what makes it actionable.** A relayed authorisation is a report of
one; **the difference matters most exactly when it is inconvenient.**

## 5. Operating knowledge

**Cite; do not duplicate.**

**List the instruments this role must know and point to them by
identifier.** A charter that restates another instrument creates two
texts that will disagree, and **the copy is always the one that goes
stale.**

## 6. Reconstitution

**How a fresh session of this role rebuilds itself.**

**State that reading this charter is an obligation exercised at every
reconstitution, not once.** A session that has read a summary of this
document has not read this document.

**State what a session must re-verify on arrival** rather than inherit —
its role, its substrate, the current state of the work, and whether any
cached text it holds still matches the repository.

---

## What a charter is not

- **Not a record of decisions.** Those belong in the practice's own
  registers, cited from here.
- **Not a place for the current state of work.** State moves; a charter
  should not.
- **Not a summary of the Rules.** Cite them.

## Filling this in

**Every section above is required.** A section that does not apply to a
role is filled with the reason it does not, **not deleted** — an absent
section is indistinguishable from an unconsidered one.

**When this charter is amended, record the amendment beside the original
rather than replacing it.** The superseded text is the record of what was
corrected, and a practice that rewrites its own history loses the ability
to see its own patterns.
