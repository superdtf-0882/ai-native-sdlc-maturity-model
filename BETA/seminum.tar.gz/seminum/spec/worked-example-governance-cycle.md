---
type: constraint_or_principle
id: SPEC-WORKED-EXAMPLE
title: Worked Example — One Governance Cycle, Start to Finish
togaf:
  phase: Preliminary
  artifact_type: Architecture Governance Framework
archimate:
  layer: Business
  element_type: BusinessProcess
---

# Worked Example — One Governance Cycle, Start to Finish

**This document is not a record of anything that happened.** It is
written to be read by a practice that has just germinated and has no
history of its own yet. Every name, date and identifier below is a
placeholder. **Nothing here is evidence; all of it is pattern.**

Read it once before your first structural change. It will take ten
minutes and will save the first argument about who does what.

---

## The shape

**Four moves, three parties, one direction.**

| | who | produces |
|---|---|---|
| **Draft** | the architecture role | a consultation brief — the question, not the answer |
| **Consult** | the execution role | a report: measurements, and where the draft is wrong |
| **Ratify** | the owner | a signature |
| **Execute** | the execution role | the change, in governed text, under an instrument |

**The order is not a convention. Each move depends on the one before it,
and skipping one leaves a specific hole:**

- **Draft without consult** → a decision made on unverified premises.
- **Consult without ratify** → two roles agreeing with each other, which
  is not authority.
- **Ratify without execute** → a decision that exists only in a
  conversation.
- **Execute without draft** → a change nobody can reconstruct the reason
  for.

---

## The cycle, moved through

### 1. The architecture role drafts

**A brief states a question and what turns on it.** It does not state
the answer as settled.

> *"Field `X` currently means two different things depending on where it
> appears. Proposal: split it. Consequence if we do: every existing
> citation of `X` needs re-reading. Consequence if we do not: a check
> keyed on `X` will silently do the wrong thing on one sheet."*

**What makes a draft good:** it names what would falsify it, and it says
which parts are measurements and which are reasoning. **A draft that
cannot be wrong cannot be reviewed.**

> **Convention worth keeping: each brief ends with a verification note
> separating *what was run* from *what was reasoned*, and names an owner
> for anything reasoned.** The named owner is who must run it later. An
> untested claim with nobody named is not an open question — it is a
> claim that will be forgotten.

### 2. The execution role consults

**The reviewing role does not agree or disagree. It measures.**

> *"Reproduced: field `X` appears on 41 items across 7 sheets. Not
> reproduced: the brief says 'every sheet' — two sheets do not carry it
> at all. And one case the brief did not consider: on one sheet the field
> is already used for something else, so the split would collide there."*

**Three outcomes are all normal:** the draft survives; the draft survives
with a correction; the draft's premise turns out false and the question
changes.

> **The third is the valuable one and the easiest to suppress.** A review
> that only ever confirms is not a review. **When a measurement refutes
> the brief, say so plainly and state what it replaces.**

### 3. The owner ratifies

**Only the owner ratifies.** Neither role may ratify on the other's
behalf, and neither may act on a ratification quoted to it inside a
document that benefits from the ratification.

> **A signature reaches the executing role directly, in the owner's own
> words, and carries its own date.** A brief may quote it so the record
> is complete — **but a quoted ratification is a report, not an
> authority.**

**Why this is strict:** the record of *what was decided* and the record
of *what was done* are different artifacts. If the second can be produced
from a claim about the first, nothing distinguishes an executed decision
from an asserted one.

### 4. The execution role executes

**Under an instrument, with the reasoning on the artifact's face.**

- **Governed text records the decision**, not the brief. A brief is a
  draft; the governed text is the instrument. **When a claim from a brief
  is recorded into governed text, the report names where it landed** —
  the artifact, the field, and where the field is a list, the element by
  its label.
- **Supersede rather than rewrite.** The superseded text stays, with the
  correction beside it. **A reader must be able to see what was believed
  before, or they cannot tell a correction from a revision.**
- **Verify by running, not by reading.** Where a claim can be tested by
  attempting the operation, reading the configuration is not evidence
  for it.

---

## What the cycle is for

**Not speed. Not consensus. It exists so that a change can be
reconstructed by someone who was not there.**

Three properties fall out of it, and each has a failure it prevents:

| property | failure prevented |
|---|---|
| every change has a **reason on its face** | a later reader re-litigating a settled question because the reason lived only in a conversation |
| every claim has a **verification class** | a reasoned guess being read as a measurement |
| every decision has **one author** | two roles converging on a view and mistaking that for authority |

---

## Two things this example cannot show you

**First: the cycle is not always four moves.** Ordinary work — a
correction, a filing, a measurement — needs no consultation. **Structural
work does:** anything that amends the schema, creates or retires a class,
changes what a check refuses, or alters a role's remit. **Deciding which
kind a piece of work is, is itself a judgment, and getting it wrong in
the ordinary direction is how ungoverned changes land.**

**Second: the cycle catches errors, and most of them are its own.** A
mature practice's record is largely a record of its own corrections —
premises that did not survive measurement, counts that were wrong,
claims that outran their artifacts. **That is the cycle working.** A
governance record with no corrections in it is not a clean practice; it
is one that is not looking.

---

## Adopting this

**Nothing here requires tooling.** The four moves work in any medium that
lets you write things down in order and keep them.

**What does require care is the boundary between roles.** Write down, on
your first day, which role may change governed text and which may not,
and what the enforcement is. **If the answer is "we trust each other" —
record that as the answer.** A boundary that is undeclared is not a
boundary, and it will be crossed by accident before it is crossed on
purpose.
