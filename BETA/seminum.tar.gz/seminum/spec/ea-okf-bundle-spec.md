# EA OKF — TOGAF® Bundle Specification
**Version:** 1.16 (OKF v0.1 Profile)
**Base format:** Open Knowledge Format v0.1 — https://okf.md
**Base license:** Apache 2.0 — GoogleCloudPlatform/knowledge-catalog
**Status:** Active — v1.16 published 2026-08-19 (numbered sequences are cited by label, never by position — the reading rule `RULE-5`’s carrier clause depends on). v1.15 published 2026-08-18 (`status` typed as a closed enum, membership moved from one flat list to per-SHEET sets, and every declared value given a falsification condition — `OI-056` Q1–Q5). v1.14 published 2026-08-17 (`seed_runtime`: the seed’s executable core, derived not listed — OI-060 closed). v1.13 published 2026-08-17 (`meta_date` given the referent it never had). v1.12 published 2026-08-17 (`6eb9b5d`) (the sheet rung retargeted to declare the header, the `instance`-only restriction retired, and `template` given an item-level meaning — `briefs/2026-08-15-activity-3-prep/`, `OI-059`). v1.11 published 2026-08-17 (`bd2bbe3`) (the ship-whole clause corrected: the unit is the item, and five of the eleven never qualified — same folder). v1.10 published 2026-08-16 (`8108539`) (the intra-item boundary ruled: ship whole for v1 — same folder, issue #64). v1.9 published 2026-08-16 (`99d50f8`) (the `seed` vocabulary defined, with its decision procedure; and the sheet-level restriction generalised — `briefs/2026-08-15-seminum-contents/`, issues #62 and #63). v1.8 published 2026-08-15 (`054416d`) (seed eligibility, EXT-008, briefs/2026-08-15-seminum-product/). v1.7 published 2026-07-22 (Framework View execution); v1.6 the same day (WP-STRATUM-01, AC-006).
**Supersedes:** v1.15
**Changes from v1.15:** **No new field, no new artifact type, and no schema change — a READING rule, and it is versioned for the same reason v1.13 was.** v1.13 added no field either; it gave `meta_date` a referent it had never had, and semantics without a version bump is the stale-status-claim failure this corpus keeps logging. **NUMBERED SEQUENCES ARE CITED BY LABEL, NEVER BY POSITION.** `WP-SEMINUM-01.wp_activities` runs `1,2,3,4,9,10,11` — **seven entries, and *activity 9* is the fifth** — and **the first four make indexing look correct**, which is what caught DT2 one step from filing that a cited carrier did not exist. **`RULE-5`’s carrier clause, ratified in the same act, depends on this**: a carrier permitting *"the fifth element"* would send a reader to the wrong entry on the only item the convention has ever been used on. **NO AUTHORING CONVENTION IS IMPOSED, deliberately** — measured at six numbered sequences corpus-wide, five contiguous, one not, so a contiguity rule would arrive **already breached by exactly the item that motivated it**, unenforced, on a population of six. **A reading rule protects all six and every future one, however written.** Drafted by DT2 in `briefs/2026-08-18-seminum-packager/28-`, ratified *"I ratify both clauses - David Facer - 8/19/2026"*, executed by CC.

**Changes from v1.14:** **No new field and no new artifact type — `status` is retyped rather than extended.** Three changes, and the second is the one that matters. **(1) `status` is a CLOSED ENUM**: the enum-plus-commentary option was rejected because it would legitimise four prose values, three of which were **unresolvable references parked in a non-reference field** — `CR-BSM-PATHA-01` and `WP3` are live IDs the graph could not see. **(2) MEMBERSHIP IS PER SHEET, NOT PER `type`.** `type: register_entry` spans seven registers with seven lifecycles, so a validator keyed on `type` would apply one set to seven kinds — the same uselessness as the flat list it replaces. **Q1’s answer was right and its wording was one level too coarse.** **(3) REQUIRED PER KIND, NO DEFAULT**: 111 of 327 items carry no `status`, and absence currently reads as *implicitly `Active`*. **A default would ASSERT a lifecycle state about items nobody has read, where `seed`’s default is safe precisely because it WITHHOLDS.** **Three of nineteen sets are declared and sixteen are owed** — blocked on their sheets being read, not omitted, because sets drafted from convention would be conventions about conventions. **Two sheets are deliberately unenforced with the reason recorded.** **Every declared value states what would falsify it**, after `OI-034` sat `Backlog` five weeks behind a reading nothing could contradict — and the exercise immediately found that **`Active` is the weakest condition and the second most common value at 67 occurrences.** Enforcement is **not written**, sequenced behind `WP-D6-06`. Drafted by DT2 across `briefs/2026-08-17-status-vocabulary/` and `briefs/2026-08-18-closed-item-sweep/`, ratified *"I ratify B through D, and A2 - David Facer - 8/18/2026"*, executed by CC.

**Changes from v1.13:** **One new schema block, `seed_runtime`, and it is not a `seed` value.** It declares **entry points and dependencies only**; the packager ships the transitive `require` closure over them. **The reframe is the change:** the tooling question is not a disclosure question — `seed` asks *may this be disclosed*, this asks *what must be present for the seed to function*, which is **dependency closure: derived, not decided.** That is why every route through `EXT-008` felt wrong and neither role could say why. **It computes rather than lists because both roles proved a manifest unsafe in one exchange** — CC derived six files, DT derived four, the answer is five. Home is this document rather than the packager so that **a seed can produce a seed**, and so `validate-corpus.js` can enforce it today. **All three refusal paths demonstrated live and reverted.** Drafted by DT2, ratified *"I ratify the mechanism - David Facer - 8/17/2026"*, executed by CC. **No `seed` value is assigned and the census is unchanged at 370** — tools do not become census rows and should not.

**Changes from v1.12:** No new field and no new artifact type. **`meta_date` is given the referent it never had.** It is **the date `meta_version` took effect** — the landing of the version the sheet currently declares; not creation, not last touch, not last ratification. **The field did not drift; it was never anchored** — three sheet headers read 2026-08-15 while their `meta_version` had landed 2026-08-16, and nobody updated them because nobody could say what they tracked. **Scoped to sheet frontmatter**: items carry no `meta_version`, so an item-level `meta_date` falls outside this definition — **the same granularity trap `template` hit at v1.12**, caught this time before it was applied rather than after. **The three were back-filled after the definition landed, not before** — the order matters, and it is `EXT-008`'s own lesson: a value assigned under an undefined field is the failure that started `WP-SEMINUM-02`. Each now matches the commit that changed its `meta_version`. **No validator rule in this version, deliberately** — DT held it back, and enforcing a referent mechanically before it is settled is worse than enforcing nothing. Drafted by DT (`briefs/2026-08-17-seed-strategy/07-` §3), ratified *"I ratify both - David Facer - 8/17/2026"*, executed by CC.

**Changes from v1.11:** No new field and no new artifact type. **`seed`'s resolution order changes shape, and a fail-open hole closes.** (1) **Two ladders, one rung each.** An item resolves item → `instance`; a **sheet header** resolves sheet → `instance`. **A sheet-level `seed` now declares the sheet's own frontmatter and can no longer reach an item.** The old cascade was a **value no-op** where items existed — the only legal value was `instance`, which is also the global default — while the header a packager *must* emit for a `pattern` item's file to parse could be declared nothing but `instance`, so it **shipped undeclared, by omission**. `OI-059` read as a coverage gap; it was a hole. (2) **The `instance`-only-where-items-exist restriction is retired, not relaxed** — its hazard cannot occur once a sheet value reaches no item. **Demonstrated by running against `constraints.md`, the 9-item file holding `C-005`**: the validator permits a sheet-level `pattern`, the header resolves `pattern`/`sheet`, and all nine items still resolve `instance`/`default`. (3) **`template` gains an item-level meaning** — container is `id`/`title`/`cp_kind`/`archimate`/`status`, content is the statement; `related` ships only for targets that themselves ship. The value was settable on an item since v1.9 with nothing stating what to emit. (4) **`seedCensus` emits a header row for every file** — **343 → 368**, 45 sheet rows and 323 item rows; the zero-item case stops being special and becomes the general rule. Drafted by DT (`08-` §2, `09-` §3), ratified *"I ratify §2, §3 and the census fix - David Facer"*, executed by CC. **DT's own account, this being the third consequence of one clause it wrote:** *"one field was answering two questions"* — what does this sheet ship, and what do its items default to. **No item is classified by this version either**: all 368 census rows resolve to `instance`.

**Changes from v1.10:** No new field and no new artifact type. **v1.10's ship-whole clause is replaced, because it was wrong twice and both were found by running.** (1) **The unit is the item, not the provenance.** `seed` is item-granular, so declaring an item `pattern` ships *every* field it carries — `cp_scope`, `cp_rationale`, `cp_implications`, `related` and the rest. Measured: **9 of the 11 items v1.10 named carry instance content outside `cp_source`**; only `RULE-1` and `C-003` are clean there. v1.10 licensed one field's worth of content when the unit was the item. (2) **Five of those eleven never qualified at all**, their *statement* being itself instance so the exception cannot reach them: `RULE-5`, `RULE-5C`, `RULE-7`, `C-008`, `FR-LEX-14`. The clause now names them so no assigner re-derives them, and **assigns them no disposition** — that is David's under `WP-SEMINUM-02`'s `wp_owner`, and *"closing this exception is not the same act as closing the item."* **So the exception is narrower in extension and wider in intension than v1.10 stated: fewer items qualify, each qualifying item ships more.** Defect (1) was found by **DT** contesting CC's wording; defect (2) by **CC** running that contest across all eleven items rather than the four DT sampled. Clause drafted by DT, ratified *"I ratify the clause - David Facer"*, executed by CC — `briefs/2026-08-15-activity-3-prep/` `04-`, `05-`, `06-`. The scoping, the v1-tradeoff framing and the `WP-SEMINUM-03` successor are **unchanged from v1.10**. **No item is classified by this version either**: all 343 census rows still resolve to `instance`.

**Changes from v1.9:** No new field, no new artifact type, and no change to the two-question procedure. **One ruling is added to `EXT-008`: where an item's *statement* qualifies as `pattern` but its *provenance* names this practice, the item is declared `pattern` and the provenance ships attached to it.** Ratified by David on the activity 3 preparation (issue #64, *"Rules — ship whole (option a) for v1"*). It affects at least eleven items — five Rules, `P-09`, `P-10`, `C-003`, `C-008` and `FR-LEX-14` — for which the alternative was classifying the Rules `instance`, which fail-closes correctly and **guts the seed, because the Rules are the governance model.** **The ruling is narrow by construction:** it applies only where the statement independently qualifies, only to that statement's provenance, and never to an item whose statement is itself `instance` — so question 1 is unchanged, not re-read. **It is a v1 tradeoff with a registered successor**, `WP-SEMINUM-03`, explicitly not gating v1. **Versioned rather than landed quietly**, because v1.9's own changelog records that a semantic change to this extension went in unversioned under #62 and that the omission was CC's. **No item is classified by this version either**: all 341 census rows still resolve to `instance`.

**Changes from v1.8:** No new field and no new artifact type — **the `seed` field gains meaning it did not have.** (1) **`pattern`, `template` and `instance` are defined**, with a two-question decision procedure ratified alongside them; v1.8 legalised three values and defined none, which would have made assignment across the corpus an unreviewable judgment for every item. (2) **The sheet-level restriction is generalised**: `pattern` or `template` are permitted at sheet level **only where the file declares no items**, because for such a file the sheet level *is* the item level. Under v1.8's wording `SPEC-STRATA` and both charters — zero-item spec documents, and the artifacts a germinated repo cannot function without — could be declared `instance` and nothing else, so they could not ship. (3) **`seedCensus` enumerates zero-item files**, 321 → 341 rows, so a coverage claim counts what actually ships. **Change (2) landed unversioned under issue #62 and is versioned here**; that omission was CC's. **No item is classified by this version either**: all 341 census rows still resolve to `instance`. Full text in `EXT-008`, `spec/extension-registry.md`.

**Changes from v1.7:** One new universal row-level field (`seed`, EXT-008) — declares whether an item is eligible to ship in a Seminum seed package. Values `pattern | template | instance`; resolves item → sheet → `instance`; **sheet level may only be `instance`.** No new artifact type, no change to any existing field, and no item is classified by this version: every item in the corpus resolves to `instance` on publication.

---

## Changelog — v1.8 (2026-08-15)

> Published under `briefs/2026-08-15-seminum-product/10-CC-execution-brief-seed-field-v2.md`, signed by David 2026-08-15, after DT's review (`08-`) and consultation (`01-`–`09-`). Extension registry: EXT-008 activated.

1. **New universal field `seed`** (§ Universal Fields) — valid on any typed item, like `archimate`. Values `pattern | template | instance`. Specified in `AV-STRATUM-001`'s `vision_constraints` on 2026-07-19 and built now.
2. **Resolution is two ladders, one rung each (v1.12):** an **item** resolves item → `instance`; a **sheet header** resolves sheet → `instance`. **A sheet-level value declares that header and never reaches an item.** The last rung is a **single global constant** on both, deliberately not the per-type default table `archimate` uses: a per-type table would let a future editor give some type a more permissive default, which is how an opt-in control becomes opt-out.
3. **Sheet-level `seed` declares that header and reaches no item** (v1.12) — so all three values are legal there, on any file, and the validator enforces no item-count restriction. **Both halves of what this line said before v1.12 are now false, and it was missed in that version's own sweep** (`briefs/2026-08-17-seed-strategy/00-index.md`): it read *"may only be `instance` — validator-enforced"* while CC's own demonstration returned exit 0. **The reason it survived is worth more than the correction**: CC swept for `may only be "instance"` with straight quotes and this line uses backticks, then reported the sweep *"clean until grep came back clean"* — **clean by pattern, claimed by meaning.** The pre-v1.12 rationale below remains correct about the semantics it described: fail-closed protects against omission, not against one wrong line, and at registration five sheets examined at item level were all five mixed, putting 45 items behind five header lines. **That hazard is retired rather than relaxed — a sheet value can no longer reach an item.**
4. **Nothing is classified.** The field ships with no value assigned anywhere. Every item resolves to `instance`, so no item is seed-eligible and no seed can ship. What is actually eligible is a separate act under `AV-STRATUM-001`.
5. **Version note.** `AV-STRATUM-001` reserved this work as a "v1.6 candidate"; v1.6 and v1.7 both shipped other extensions on 2026-07-22, and this registry's own Roadmap had reserved v1.8 for the vocabulary consolidation pass, which rolls to v1.9. Reservations are displaced by what actually ships — the precedent the Roadmap already records for `wp_rule9_class`.

**Changes from v1.6 (v1.7):** One new artifact type (`framework_entry`, EXT-007) — Ontology/Lexicon/Taxonomy entries for the practice's own meta-model, formalizing content from `market/ea-okf-ontology-lexicon-taxonomy.md` into governed corpus rows. The Stratum Model itself is deliberately NOT forked into this type — `SPEC-STRATA` remains sole authority; `framework_entry` rows that carry a `stratum` value reference it by `derives_from`, never restate it. Two documentation-only fixes carried in the same pass: `sheet_description` (in live use since 2026-07-15, `standards.md`) and `Superseded` (in live use since 2026-07-19, `AV-BROWSER-001`) were never formally added to this spec — both added now, no behavior change, closing a gap CC's own schema-version check surfaced.

---

## Changelog — v1.7 (2026-07-22)

> Published under the Framework View execution (briefs/2026-07-22-framework-execution/), following CC's proposal (briefs/2026-07-22-olt-stratum-framework-proposal/) and DT's review. Extension registry: EXT-007 activated.

1. **New artifact type `framework_entry`** (§ Type-Specific Fields 11) — Ontology, Lexicon, and Taxonomy entries (the practice's own meta-model), distinguished by a `framework_category` field. Corpus home: `corpus/framework.md`. A `display_order` field on each category drives presentation order in a schema-generic reader (Vellum) without hardcoding order in application code.
2. **Stratum is referenced, not forked.** `framework_entry` rows that assign a `stratum` value carry a `related: [{id: "SPEC-STRATA", relationship: "derives_from"}]` edge; the eight-stratum model itself is never re-typed as `framework_entry` rows. `SPEC-STRATA` remains the sole authoritative source — the two-texts-two-truths failure this practice has caught and killed everywhere else (the shared parse core, the validator/Vellum "one parser" rule) does not get reintroduced here.
3. **`sheet_description` documented** (§ Universal Fields) — an optional sheet-level free-text field, in live, undocumented use since 2026-07-15 (`standards.md`). No behavior change; this is the spec catching up to an existing convention.
4. **`Superseded` added to the `meta_status`/row `status` controlled vocabulary** — in live, undocumented use since 2026-07-19 (`AV-BROWSER-001`, `status: "Superseded"`, `AV-STRATUM-001`'s supersession). No behavior change; same as (3), the spec catching up to an existing convention.

---

## Changelog — v1.6 (2026-07-22)

> Published under WP-STRATUM-01 (AC-006). Extension registry: EXT-006 activated.

1. **New artifact type `corpus_index`** (§ Type-Specific Fields 10) — a singleton: exactly one file per EA OKF corpus (the root `README.md`) carries this type. Frontmatter only (`id`, `title`, `meta_*`, optional `related:`) — no `items:` list; the body is free-form Rules/SOP/File-Index prose, per Design Principle 7's tolerance for prose-only bodies. Gives the one corpus file that previously carried no frontmatter at all a resolvable `id`, so a schema-generic reader (Vellum) can route to it the same way it routes to every other file, without a repo-specific special case.

---

## Changelog — v1.5 (2026-07-16)

> Published under WP-D6-01. Theoretical grounding: `spec/strata-and-intent-fibering.md` (SPEC-STRATA). Extension registry: EXT-005 activated.

1. **New artifact type `architecture_contract`** (§ Type-Specific Fields 9) — the governed issuance of work to an implementation agent; the S4→S5 junction in SPEC-STRATA's strata model. Corpus home: `corpus/architecture_contracts.md` (single file, `items:` list, same pattern as `adrs.md`).
2. **Type-index fields introduced** — `realizes` and `ac_governing_refs` on `architecture_contract` are *constitutive*, not descriptive: required, non-empty, and every referenced ID must resolve. A contract missing either is ill-formed and fails validation. This is deliberate (SPEC-STRATA § Schema consequences 1) and is not softened to optional for consistency with other types. Other relationship expressions remain descriptive.
3. **Legal reference namespaces stated normatively** (Assertion Rule 5) — `related[].id` and type-index references must resolve in exactly three namespaces: corpus row-item IDs, corpus sheet-level IDs, and spec-document IDs (any spec file with a frontmatter `id:`). Free-floating mnemonics are illegal targets. (Formalizes what the dangling-reference sweep previously treated as advisory.)
4. **`adr_amendments` list field on `architecture_decision_record`** — formalizes the amendment-note precedent (ADR-007 v1.1, ADR-006 historical clarification) as a structured field instead of prose in `notes:`.
5. **Correspondence vocabulary** (§ Correspondence Vocabulary) — Work Package, Architecture Contract, Brief, Report; their strata positions; and the normative brief-thinning consequence: with a contract issued, the brief is transport, not governance.
6. **ID-series note:** the `AC-XXX` series was previously used for application rows retired at v1.4 (`AC-001`→`A2`, `AC-002`→`A4`, `AC-003`→`A10`; zero live references remain, verified at v1.5 authoring). The series is re-based here for Architecture Contracts. Historical exports and git history predating 2026-07-09 use `AC-*` in the retired sense.

---

## Changelog — v1.4 (2026-07-08)

> **Locked Active 2026-07-09.** Import/export settled (AMEFF) and the Platform Migration corpus migrated + verified (`related_to` 13.6%, 0 dangling refs). Per Design Principle 6, further structural change requires a new version and a changelog entry.

1. **Row-Level Field Schemas added** (§ Row-Level Field Schemas). v1.3 defined sheet-level fields but never the per-row (item) fields; the `items:` bodies had evolved an undocumented bare vocabulary per category. Now normative. Root cause: Archi export could not map row fields (`notes`, `repository`, `current_url`, `hosting_current`) because the schema did not define them. New **Design Principle 10**.
2. **Element-uniqueness rule** — an element is defined exactly once, in a catalog or register row; views and other artifacts reference IDs only. New **Design Principle 11**. Resolves `AC-001/002/003`, which existed only inside `VIEW-AC-01` yet were referenced ~10× as relationship targets → resolved to `A2`, `A4`, and new row `A10`.
3. **Bookkeeping demoted to annotations** — cross-references whose purpose is tracking or navigation (chiefly to Open Items) move from `related:` edges to the `open_items:` row annotation. New **Design Principle 12**; **Relationship Assertion Rule 1** amended. Root cause: 18 of 45 residual `related_to` edges were open-item bookkeeping, inflating `related_to` to 24.3% (target <15%).
4. **New relationship `shares_infrastructure_with`** — for artifacts that share underlying infrastructure with no dependency direction (e.g. two data stores on one physical Redis instance, key-namespaced). Bidirectional.
5. **Row-core `status` field** — element-level lifecycle, distinct from sheet-level `meta_status`.
6. **Sheets are non-exported containers** — a sheet is organizational; sheet-level `related:` is documentation-level and is not exported to ArchiMate tooling.
7. **`view_membership` field** — optional declarative selector on `architecture_view` rows defining which elements a generated ArchiMate view contains (see View Membership). Backs the AMEFF export approach settled for v1.4.

> **Note on the export format.** The canonical export is the **ArchiMate Model Exchange File Format (AMEFF)** — see `ameff-export-spec.md`. The three-file CSV import (`archi-csv-import-spec.md`) is retained as legacy. The schema itself is export-mechanism-neutral.

### Amendment — 2026-07-15 (WP-D6-03, corpus access by reference)

Added a corpus-by-reference instruction to the Deputy TOGAF Contract Note (above): before any work package, retrieve current corpus content by ID rather than trusting brief-embedded content as authoritative. This is a behavioral/procedural instruction for the AI agent consuming the schema, not a change to any field, type, vocabulary, or YAML structure — so it rides as an amendment to v1.4 rather than a new version, per this brief's explicit instruction. `type: architecture_contract` and any other structural change remain scoped to v1.5 (WP-D6-01).

---

## Design Principles

1. **Universal fields are flat.** All artifacts carry the same base set of `meta_` prefixed fields.
2. **Framework fields are nested.** `togaf:` and `archimate:` blocks isolate framework vocabulary from operational metadata.
3. **Type is the schema discriminator.** The `type` field (snake_case) determines which type-specific fields are valid.
4. **Relationships are first-class.** The `related:` block carries typed, traversable cross-references. See Relationship Assertion Rules — assertion discipline is as important as type selection.
5. **ArchiMate element type is optional but encouraged.** Where an artifact maps cleanly to an ArchiMate element, the mapping should be declared explicitly.
6. **The schema is a living document.** New fields are appended, not retrofitted. Changes require a version increment and a changelog entry.
7. **Body format is governed by sheet character, not a uniform rule.** Dense catalogs and registers use a YAML `items:` list in the body. Single-artifact sheets use a prose body. View artifacts use prose with embedded YAML. The unit of decomposition is the sheet — each markdown file represents one sheet, with rows as `items:` list entries.
8. **Relationships and ArchiMate mappings are valid at both sheet level and row level.** The frontmatter `related:` and `archimate:` blocks declare sheet-level identity. Each item in an `items:` list may carry its own `related:` and `archimate:` fields at element level. Item-level `archimate:` overrides the sheet-level default.
9. **Tabular reconstitution adds a banner row, not a data row.** When rendered to Excel or CSV, the first row is a banner: sheet title, `type` value, `catalog_category` or `register_category` if applicable, and schema version. Second row is the column header. Data rows follow. Governance notes belong in the frontmatter body — not as data rows.
10. **Row fields are bare; sheet fields are prefixed.** Sheet-level type-specific fields carry the type prefix (`catalog_*`, `register_*`, `adr_*`, `cp_*`, `wp_*`, `view_*`, `stakeholder_*`, `review_*`). Row-level (item) fields are bare and defined per category in the Row-Level Field Schemas. The prefix is the reader's cue to sheet-vs-row scope.
11. **An element is defined exactly once.** Every element is defined in exactly one catalog or register row. Views, ADRs, roadmaps, and all other artifacts *reference* element IDs via `related:` — they never introduce a new element definition inline. A referenced ID that resolves to no row is an authoring error, not a new element.
12. **Bookkeeping links are annotations, not relationships.** A cross-reference whose purpose is tracking or navigation — chiefly to an Open Item — is recorded in a row annotation field (`open_items:`), not as a `related:` edge. `related:` is reserved for architecture relationships: governance, realization, dependency, derivation, instantiation, infrastructure-sharing.

---

## Controlled Vocabularies

### `type` values
| Value | TOGAF Artifact Name |
|---|---|
| `architecture_decision_record` | Architecture Decision Record |
| `catalog_entry` | Various catalog types |
| `register_entry` | Various register types |
| `compliance_review` | Architecture Compliance Review |
| `stakeholder` | Stakeholder Map entry |
| `constraint_or_principle` | Constraints Catalog / Architecture Principles |
| `architecture_view` | Information / Data / Application View |
| `roadmap_entry` | Architecture Roadmap / Work Package |
| `architecture_contract` | Architecture Contract (Phase G) — v1.5, EXT-005 |
| `corpus_index` | Corpus Index (no TOGAF® analog — the corpus's own root README) — v1.6, EXT-006, singleton |
| `framework_entry` | Ontology / Lexicon / Taxonomy entry (no TOGAF® analog — the practice's own meta-model) — v1.7, EXT-007 |

### `meta_status` / row `status` values

**`status` IS A CLOSED ENUM** (v1.15, `OI-056` Q4, ratified *"I ratify B through D, and A2 - David Facer - 8/18/2026"*, drafted by DT2 in `briefs/2026-08-17-status-vocabulary/09-`). A value outside its kind's set is a defect, not a variant. **There is no enum-plus-commentary form**, and the dichotomy that suggested one was false: of the four prose values found in the corpus, **three were field misuse and one was a missing state** — see the dispositions below.

**AND THE MEMBERSHIP IS PER SHEET, NOT PER `type`** (v1.15, `OI-056` Q3). `type: register_entry` spans **seven registers with seven different lifecycles** — an assumption is `Active`, an interface is `Complete`, a risk is `Mitigated`. **A validator keyed on `type` would apply one set to seven kinds and be useless in exactly the way the flat list below was.** `catalog_entry` spans three sheets and does the same. **The lifecycle belongs to the kind of thing, and in this corpus the kind is identified by the sheet.**

> **REQUIRED PER KIND, WITH NO DEFAULT** (v1.15, `OI-056` Q2/Q4). Where a set is declared, `status` is **required**. **No default value is supplied, and this is deliberate**: 111 of 327 items currently carry no `status` at all, and absence today reads as *implicitly `Active`* — fail-open. **A `status` default would ASSERT a lifecycle state about items nobody has read; `seed`'s default is safe only because it WITHHOLDS.** The two look alike and are opposite. The unfilled items are a **filling backlog, not a violation** — the check warns before it refuses, and refusal turns on per sheet as each is filled.

**EVERY VALUE STATES WHAT WOULD FALSIFY IT.** A vocabulary of unfalsifiable states satisfies the per-kind requirement and buys nothing: `OI-034` sat `Backlog` for five weeks because *the board's leftmost column* was a reading no observation could contradict. Under *accepted for execution and not started* it was checkable, was checked once, and failed.

#### Declared sets — three of nineteen

**The other sixteen sheets are owed and are blocked on their contents being read, not omitted.** Until a sheet's set is declared, its `status` is unconstrained and unrequired.

**`register_open_items` (`register_entry[OpenItem]`)**

| Value | Falsified by |
|---|---|
| `Open` | a resolution recorded in the item, or a successor holding what it asked |
| `Backlog` | **any artifact the item names as its output exists** |
| `Active` | nothing cites it and nothing has changed under it since a stated date — **weak; see the note below** |
| `Blocked` | **either** the `dependency` names a resolvable ID and that target reaches a terminal state, **or** any artifact the item names as its output exists |
| `Closed` | a later item registers the same subject |
| `Complete` | the work the item named is absent |
| `Superseded` | **no successor that RESOLVES AND IS NOT ITSELF TERMINAL, or a successor that does not hold what the item held** |

**`Superseded`'s successor test turns on *resolves and is not itself terminal*, not on *is a corpus item*** (added 2026-08-19, ratified in the `B through D` block of *"I ratify B through D, and A2 - David Facer - 8/18/2026"* as workbook item C3, and **landed late — CC executed C1, C2, C4 and C5 at issue #83 and missed this one, found by sweeping for outstanding ratifications rather than by anything failing**). **The narrower reading — that a successor must be a corpus item — would make supersession into a spec document inexpressible**, and this practice supersedes into specs routinely: `ROADMAP-D6` resolves in the ID universe alongside `CHARTER-CC` and `SPEC-DISPATCH-SOP` but **carries no `status` at all**, so *"a live item"* has nothing to test against it. **The two clauses of the condition came apart on exactly that case** — *does the successor hold what the item held* is testable against a spec document; *is it a live item* is not. **`OI-034` is the worked example: one of its two successors is `AV-D6-001`, an `Active` item, and the other is `ROADMAP-D6`, a spec document.** Under the item-only reading only half its falsification condition would have been expressible.

**`Complete` and `Closed` are kept as two:** `Complete` means the work the item named was done; `Closed` means the item stopped being live without that — superseded, withdrawn, or answered elsewhere. 30 `Complete` against 9 `Closed` says the distinction is already in use.

**`Superseded` earns its place by carrying a checkable claim that `Closed` does not** — a validator can require a `related:` edge to a live target. **`Ready` is absent deliberately:** it names a position in a particular board's workflow and asserts nothing outside it, and in this corpus it asserted a startability that was false.

**`Blocked`'s second limb is the general one** and needs nothing from `dependency`: it is deliberately the same observable as `Backlog`'s, because **`Backlog` and `Blocked` are the same underlying state — accepted, not started — differing only in the stated reason**, and a test of the state should not depend on which reason was recorded. **Residue, recorded rather than papered over:** a prose-blocked item whose blocker has cleared and whose work has not started remains unfalsifiable from inside the corpus. One row today (`OI-015`, `dependency: "External API access"`). **No re-check date is imposed**, because that would convert `Blocked` into a rate check — the defect that makes `Active` the weakest value in the corpus.

**`roadmap` (`roadmap_entry`)**

| Value | Falsified by |
|---|---|
| `Backlog` | as above |
| `Active` | as above — weak |
| `Complete` | the work package's own completion criteria unmet by any artifact |
| `Superseded` | as above |

**`register_requirements` (`register_entry[Requirement]`)**

| Value | Falsified by |
|---|---|
| `Draft` | a ratification exists for the text |
| `Active` | its `acceptance_criteria` are all met by named artifacts |
| `Conditional` | **the condition has triggered** |
| `Satisfied` | any `acceptance_criteria` unmet by any artifact |
| `Withdrawn` | a governed artifact still cites it as live |

> **`Active` IS THE WEAKEST VALUE AND THE SECOND MOST COMMON, AT 67 OCCURRENCES.** Every other value's condition is a **state** check — does the successor exist, does the artifact exist, has the blocker cleared. **`Active`'s is a rate check — *is anything happening* — which needs a time window, and a window is a judgment.** So the largest population in the corpus sits behind the weakest test, and **that is where the next `OI-034` will be.** No window is stated here, because putting a number in the schema would make it look checkable. **`Active` is strongest where the sheet carries a criteria field and weakest where it does not** — a structural observation about the sheets, not about the value, which suggests the remedy is a criteria-bearing field rather than a better definition.

#### The four prose values, dispositioned

| Item | Was | Disposition |
|---|---|---|
| `A3` | `Active — own artifact set` | `Active`; the scope fact → `notes` |
| `A5` | `Active — governed product (… CR-BSM-PATHA-01 …)` | `Active`; **`CR-BSM-PATHA-01` → a `related:` edge**, the rest → `notes` |
| `PROMPT-V1` | `Approved — deployed to Production with WP3` | `Approved`; **`WP3` → a `related:` edge**, the deployment fact → `change_description` |
| `RC-005` | `Conditional — not triggered` | **held** — the only one whose current value says something true that no declared value said; `Conditional` is now declared above |

> **Three of the four were not untidy statuses — they were unresolvable references parked in a non-reference field.** `CR-BSM-PATHA-01` and `WP3` are **live governed IDs that resolve**, and the graph could not see them because they sat in prose. **Moving the prose without adding the edges would preserve the defect while appearing to fix it.**

#### Two sheets deliberately unenforced

**`catalog_tech_components`** — `Active` (21) and `Complete` (16). **`Complete` is not a lifecycle state of a component**; a component is built, in use, or retired, and *complete* describes the work that produced it. **So either 16 rows are mistyped or `Complete` means something here that has not been recovered** — and resolving that inside a vocabulary draft would smuggle 16 retypes into a schema change, or declare a value believed wrong. **`register_assumptions`** — one item. **One observation cannot ground a closed set**, and unlike `catalog_data_stores` it has **no sibling sheet with a shared lifecycle to borrow from**, which is the actual distinguishing ground. **Both remain unenforced with the reason recorded, because an honest gap beats a confident set.**

#### Enforcement

**Not written.** `OI-056` Q5, sequenced **behind `WP-D6-06`** (code-gate CI) rather than before it. **Any check must key on the sheet, not on `type`** — and note that `register_requirements` items carry their own `type:` field meaning a requirement taxonomy (`OI-064`), so a `type`-keyed check would read `Deployment gate` as a schema type.

*(`meta_status` = sheet editorial state; row `status` = the element's own lifecycle. **They no longer share one vocabulary** — the sets above govern row `status` per sheet; `meta_status` retains the flat historical list below. `Superseded` was added at v1.7, documenting a convention in live use since 2026-07-19.)*

**`meta_status` (sheet editorial state):** `Draft` | `Approved` | `Active` | `Complete` | `Living` | `Backlog` | `Blocked` | `Deprecated` | `Accepted` | `Prototype` | `Superseded`

### `related[].relationship` values
| Value | Meaning | ArchiMate analog | Archi CSV Type |
|---|---|---|---|
| `depends_on` | This artifact requires the target to function | Association / Serving | `ServingRelationship` *(Source/Target reversed in CSV — serving element is Source)* |
| `governed_by` | This artifact is constrained by the target | Association | `AssociationRelationship` |
| `governs` | This artifact constrains the target | Association | `AssociationRelationship` |
| `realizes` | This artifact implements or satisfies the target | Realization | `RealizationRelationship` |
| `derives_from` | This artifact was produced from the target | Influence | `InfluenceRelationship` |
| `supersedes` | This artifact replaces the target | Association | `AssociationRelationship` |
| `instantiates` | This artifact is a specific instance of the target pattern or decision. Applies to applications instantiating ABB patterns AND data stores instantiating storage governance decisions. | Realization | `RealizationRelationship` |
| `shares_infrastructure_with` | Two artifacts share underlying infrastructure with no dependency direction (e.g. one physical store, key-namespaced; dedicated vs pre-existing store of the same class). **Bidirectional — assert once from either side.** | Association | `AssociationRelationship` |
| `related_to` | General association — no stronger type applicable. **Last resort only.** Bidirectional. | Association | `AssociationRelationship` |

### `archimate.layer` values
`Business` | `Application` | `Technology` | `Motivation` | `Implementation`

### `archimate.element_type` values
| Value | Layer |
|---|---|
| `BusinessActor` `BusinessRole` `BusinessFunction` `BusinessProcess` `BusinessService` `BusinessObject` | Business |
| `ApplicationComponent` `ApplicationService` `ApplicationFunction` `DataObject` | Application |
| `Node` `TechnologyService` `Artifact` | Technology |
| `Requirement` `Constraint` `Principle` `Goal` | Motivation |
| `Plateau` `WorkPackage` | Implementation |

### Multi-value field separator
YAML frontmatter: one item per line in array fields.
Tabular output (Excel/CSV): **semicolon-space** (`; `) as separator within a single cell.

---

## Relationship Assertion Rules

**Rule 1 — Source-grounded assertion only.**
Only assert a relationship directly stated in the source material OR directly derivable from a type-specific field. Permitted derivations: `wp_prerequisites` yields `depends_on`; `catalog_dependencies` yields `depends_on`. **Open-item and pure-navigation cross-references are recorded in `open_items:` (or another annotation field), never as `related_to`** (Design Principle 12). Do not infer relationships from semantic proximity or structural adjacency alone.

**Rule 2 — `related_to` is the relationship of last resort.**
Before using `related_to`, confirm that none of `governed_by`, `governs`, `depends_on`, `derives_from`, `realizes`, `supersedes`, `instantiates`, or `shares_infrastructure_with` apply. A well-formed corpus should have fewer than 15% of its relationships typed as `related_to`. Bookkeeping links are excluded from the graph entirely (Rule 1), so this threshold now measures only genuine associations.

**Rule 3 — Relationships are directional.**
A → B does not imply B → A. Do not add the reverse direction unless it carries distinct semantic meaning. Exception: `related_to` and `shares_infrastructure_with` are bidirectional by definition — assert once from either direction.

**Rule 4 — Relationship count expectation.**
A well-formed corpus has approximately 0.8–1.2 `related:` edges per item at the item level. A count materially above 1.5 signals Rule 1 or Rule 2 is being violated. Annotations (`open_items:`) do not count toward this figure.

**Rule 5 — Legal reference namespaces (v1.5, normative).**
Every `related[].id` and every type-index reference (`realizes`, `ac_governing_refs`) must resolve in exactly one of three namespaces: **(a)** corpus row-item IDs, **(b)** corpus sheet-level frontmatter IDs, **(c)** spec-document IDs — any file under `spec/` carrying a frontmatter `id:`. Free-floating mnemonics — doctrine names, sheet nicknames, initiative slugs with no registered artifact — cannot carry a reference and are illegal targets. (SPEC-STRATA § Schema consequences 2: only registered artifacts can carry the intent fiber.) Pre-v1.5 corpus content contains known violations of this rule; they are tracked for remediation, not grandfathered as conformant.

---

## Universal Fields (all artifact types — sheet-level frontmatter)

```yaml
---
type: ""                    # Required. snake_case discriminator.
id: ""                      # Required. Sheet identifier.
title: ""                   # Required, EXCEPT where withheld by a `template` declaration (EXT-008 clause 5). Human-readable name.
meta_status: ""             # Required. Sheet editorial state. See controlled vocabulary.
meta_version: ""            # Required. Semantic version (1.0, 1.1, etc.)
meta_owner: ""              # Required. First name only for public artifacts.
meta_initiative: ""         # Required. Slug (platform-migration, d6-governance).
meta_date: ""               # Required. ISO 8601. THE DATE meta_version TOOK
                            # EFFECT -- the landing of the version this sheet
                            # currently declares. NOT creation, NOT last touch,
                            # NOT last ratification. A commit changing
                            # meta_version must change this to that commit's
                            # date. Defined at v1.13; before that the field had
                            # no stated referent and three sheets had drifted.
                            # SHEET FRONTMATTER ONLY -- items carry no
                            # meta_version, so an item-level meta_date is
                            # outside this definition (see EXT-008's note).
togaf:
  phase: ""                 # Required. ADM phase(s).
  artifact_type: ""         # Required. TOGAF vocabulary name.
archimate:
  layer: ""                 # Optional. Sheet-level default.
  element_type: ""          # Optional. Sheet-level default.
related:                    # Optional. SHEET-to-SHEET only; documentation-level; NOT exported (see Principle 12 / Archi notes).
  - id: ""
    relationship: ""
sheet_description: ""       # Optional. Free-text orientation for the sheet as a whole --
                             #   what it holds, what it deliberately excludes, how to read
                             #   it. Documented v1.7; in live use since 2026-07-15
                             #   (standards.md).
seed: "instance"            # Optional. Declares THIS HEADER's own seed eligibility.
                            # Since v1.12 it is NOT a default for the items
                            # below it -- items resolve item -> "instance"
                            # independently. All three values legal here.
                             #   ONLY "instance" is legal here (v1.8, EXT-008). To ship an
                             #   item -- "pattern" or "template" -- declare it on the item.
---
```

### `seed` — seed eligibility (v1.8, EXT-008)

**A universal row-level field, valid on any typed item**, the same way `archimate` is. It declares whether an item may ship in a Seminum seed package (`AV-STRATUM-001`).

| | |
|---|---|
| **Values** | `pattern` \| `template` \| `instance` — **defined in `EXT-008`, with the decision procedure**. Not restated here: one home, not two |
| **Resolution** | **two ladders, one rung each** (v1.12) — item → `instance`, and sheet header → `instance` |
| **Sheet level** | **declares the sheet's own frontmatter; never a default for the items beneath it.** All three values legal on **any** file. The `instance`-only-where-items-exist restriction is **retired** (v1.12) — not relaxed: a sheet value can no longer reach an item, so its hazard cannot occur by that route. Full rationale in `EXT-008` |

**Two things about this field differ from `archimate` deliberately, and both are safety properties.**

**The third rung is a constant, not a table.** `archimate` falls through to a per-type default table (`spec/ameff-export-spec.md`). `seed` falls through to the single value `instance`. A per-type table invites a future editor to give some type a more permissive default, and there is no legitimate reason for any type to default to `pattern`.

**The legal values are position-dependent.** Stated as a reason and not only a rule, so a later editor does not read the asymmetry as an oversight and "fix" it: *sheet level is a convenience for declaring a wholly-instance sheet once. It is not a place to ship from, because a header line is not where anyone looks for a disclosure decision.* Fail-closed protects against **omission**; it does not protect against **one wrong line**.

**Absent defaults to `instance` — nothing ships by omission.** A consumer that needs to distinguish *declared* `instance` from *defaulted* `instance` must ask the parser, which reports both (`tools/lib/corpus-parser.js`, `seedFor`). Both are safe; only one has been audited.

> **Deputy TOGAF Contract Note**
> This schema is the Architecture Contract for all future artifact authoring. Any AI agent producing or consuming OKF markdown files must read this schema before acting. It governs: type discrimination, field naming and scope (Principle 10), controlled vocabularies, body format selection, element uniqueness (Principle 11), relationship expression at both sheet and row level, the annotation-vs-relationship boundary (Principle 12), Relationship Assertion Rules, banner row convention, and multi-value field separator. Deviations require a schema version increment — not ad-hoc field invention.
>
> Every EA OKF file is OKF v0.1 conformant — the `type` field, YAML frontmatter, and markdown body follow the OKF base spec; all TOGAF®-specific field prefixes, relationship vocabulary, RAID+ framework, and ArchiMate mappings are EA OKF additions on top of OKF's minimal surface.
>
> Before any work package, retrieve the current content of every corpus ID referenced in the issuing brief or Architecture Contract. Do not proceed if a referenced ID does not resolve; flag resolution failures before beginning work. Brief-embedded corpus content, where present, is convenience — the live corpus is authoritative on any divergence. (v1.4 amendment, 2026-07-15 — WP-D6-03, corpus access by reference.)

---

## Seed runtime (`seed_runtime`)

**What must be present for a seed to function.** Added v1.14 (`OI-060`), drafted by DT2 in `briefs/2026-08-17-rescore/04-DT2-oi060-mechanism.md`, ratified *"I ratify the mechanism - David Facer - 8/17/2026"*.

**This is not a disclosure question, and that is why every route through `EXT-008` felt wrong to both roles and neither could say why.** `seed` asks **may this governed content be disclosed** — a per-item judgment, David's, defaulting closed. This asks **what must be present for the seed to function**, which is **dependency closure: derived from the code, not decided by anyone.** Asking one field to answer both is `OI-059`'s defect, and it was nearly committed a fourth time.

**One decision remains and it is small: which entry points a seed requires. Everything else follows.**

```yaml
seed_runtime:
  entry_points:
    - tools/checkpoint-a.js      # proves germination
    - tools/validate-corpus.js   # proves the corpus parses
    - tools/checkpoint-b.js      # proves the practice survives contact
                                 #   with something it does not control
  dependencies:
    js-yaml: "^4.1.0"
```

**Normative rules.**

1. **Entry points and dependencies only — never a file list.** A `files:` key is refused. The moment it lists files it is a manifest, and manifests are what this mechanism exists to avoid.
2. **The packager ships the transitive `require` closure** over the declared entry points, resolving **both** string-literal and computed `require(path.join(...))` forms. It emits a `package.json` carrying the declared dependencies and **never a vendored `node_modules/`**.
3. **It refuses, non-zero, if** an entry point does not resolve; any module in the closure is missing; the closure reaches outside `tools/`; or the closure loads an external dependency the declaration does not name.
4. **The entry-point list is the whole control surface.** Nothing unreachable from an entry point ships — which is how the `gh`-coupled tools (`type-issue`, `close-gate`, `dispatch-gate`, `check-evidence-fiber`, `lib/kanban`), `dt-outbox.js`, `dt-clone/*` and `hooks/*` stay out **by construction rather than by judgment.** A germinated practice with no GitHub receives no GitHub tooling.

   > **`checkpoint-b.js` was on that list until 2026-08-21 and is now an entry point**, ratified *"I ratify all four - David Facer - 8/21/2026"*, drafted by DT2 in `briefs/2026-08-21-run4/04-DT2-checkpoint-b.md`. **The sentence above was the only place its exclusion was ever recorded, and it recorded that exclusion as *by construction rather than by judgment* — which was exactly true and exactly the problem.** A germinated practice rebuilt the capability from scratch because nothing had decided it should not have it. **It now ships by decision, and this note is what the difference looks like.**
   >
   > **What ships is not the capability.** The file is a worked example of treating an uncontrolled service's output as data: *"nothing parsed from the feed is executed, evaluated, interpolated into a shell or a query, or allowed to influence control flow … a headline that reads like an instruction is a headline."* **A practice's first contact with something it does not operate is where that discipline either exists or does not** — and the practice that rebuilt the scraper did not rebuild the reasoning, because it never saw it.
   >
   > **Per rule 5, measured before adding rather than after:** the closure goes from **6 files to 7**, adding **only `checkpoint-b.js` itself**, with **externals unchanged** — it uses `fetch`, a Node builtin. **Nothing in the closure invokes it**, so it is inert unless a recipient runs it deliberately.
5. **No entry point is added without computing what it drags in.** Measured: `close-gate`, `dispatch-gate` and `check-evidence-fiber` each add only themselves; `type-issue` adds itself plus `lib/kanban.js`. They do not cascade — but the closure is the answer, not the expectation.

**Why here and not in the packager.** **A seed should be able to produce a seed.** If `seed_runtime` lived only in packager configuration and the packager did not itself ship, a germinated practice could never germinate another — the definition of its own executable core would be the one thing it did not receive. This document ships. And in schema it is **checkable**: `validate-corpus.js` asserts the declaration and computes the closure on every run, today, long before any packager exists. *A convention a validator enforces is a control; one it does not is a note.*

**Why it computes rather than lists, which is evidence rather than taste.** CC and DT2 each hand-derived the minimum file set in the same exchange. **CC returned six files; DT2 returned four; the answer is five.** CC included `lib/yaml-scalar.js`, which nothing in the closure requires. DT2 missed `lib/fiber-check.js` because `checkpoint-a.js` requires it through a computed path its literal-only matcher could not see. **Two careful parties, same exchange, wrong in opposite directions.** That is not an argument for more care.

> **The closure observing itself enlarges itself, and this is correct.** Implementing the check inside `validate-corpus.js` — an entry point — brought `lib/seed-runtime.js` into the closure, taking it from five files to six. DT2 pre-committed that *"a different number means the resolver disagrees"* and is **a finding, not a discrepancy to reconcile.** The finding: a germinated practice must be able to validate its own `seed_runtime`, so the resolver is part of what it needs. **The growth is the mechanism being self-applying, not a defect in it.**

**Open, not decided here:** whether the packager itself ships. This mechanism forecloses neither answer.

---

## Row-Level Item Schema (catalog_entry and register_entry bodies)

**Row core — every item carries these:**

```yaml
items:
  - id: ""                  # Required. Row identifier (globally unique across the corpus).
    title: ""               # Required. Human-readable name.
    status: ""              # Optional (recommended). Element lifecycle. See controlled vocabulary.
    notes: ""               # Optional. Free text → Archi Documentation.
    archimate:              # Optional. Overrides sheet-level archimate for this item.
      layer: ""
      element_type: ""
    related:                # Optional. Architecture relationships ONLY (Principle 12). Same vocabulary and Rules as sheet level.
      - id: ""
        relationship: ""
    open_items: []          # Optional annotation. IDs of Open Items that track this element. NOT a relationship.
    # ... plus per-category extension fields (see Row-Level Field Schemas) ...
```

**Scope rules:** Sheet-level `related:` = sheet-to-sheet (documentation only, not exported). Item-level `related:` = element-to-element (exported). Item-level `archimate:` overrides sheet-level where element type differs.

---

## Row-Level Field Schemas (per category — normative, Principle 10)

Bare field names as used in the corpus. Every row also carries the row core above.

### Catalog rows (`catalog_entry`, by `catalog_category`)

| Category | Row extension fields |
|---|---|
| `Application` | `cluster`, `audience`, `repository`, `current_url`, `hosting_prior`, `hosting_current` |
| `Technology` | `path`, `component_type`, `platform_prior`, `repository`, `dependencies[]`, `has_server_logic` (bool), `migration_effort`, `gap_type` |
| `DataStore` | `store_type`, `project`, `data_held`, `key_prefix`, `cache_key_format` |
| `ABB` | `category`, `derived_from`, `statement`, `pattern_a`, `pattern_b`, `implementation`, `applies_to[]` |
| `DesignPattern` | `category`, `scope`, `value`, `usage` |

### Register rows (`register_entry`, by `register_category`)

| Category | Row extension fields |
|---|---|
| `Risk` | `category`, `register_likelihood`, `register_impact`, `register_rating`, `mitigation` |
| `OpenItem` | `source`, `owner`, `priority`, `dependency` |
| `Requirement` | `source`, `priority`, `type`, `description`, `acceptance_criteria`, `prompt_reference`, `cache_key_format` |
| `Interface` | `domain`, `record_type`, `target_value`, `cf_proxy`, `value_source`, `record_creator`, `propagation` |
| `Prompt` | `version`, `date`, `file_constant`, `approved_by`, `source_document`, `change_description`, `required_output_sections[]`, `output_spec` |

Rows in the single-artifact types (`architecture_decision_record`, `compliance_review`, `stakeholder`, `constraint_or_principle`, `architecture_view`, `roadmap_entry`) use the row core plus the documented type-prefixed fields below.

---

## Type-Specific Fields (sheet-level — unchanged from v1.3)

### 1. `architecture_decision_record`
```yaml
adr_context: ""            # Required.
adr_decision: ""           # Required.
adr_rationale: ""          # Required.
adr_alternatives: []       # Required. "Option A: [desc]. Rejected: [reason]."
adr_risks: []              # Optional.
adr_implications: []       # Optional.
adr_approval: ""           # Required. "Approved — [name] ([date])"
adr_derives_principle: ""  # Optional. ID of derived Architecture Principle.
adr_amendments: []         # Optional (v1.5). Structured amendment history: "vN.N (date): [summary]".
                           #   Formalizes the notes-field amendment precedent (ADR-007 v1.1).
                           #   The reconstituted artifact represents the amended state.
```
### 2. `catalog_entry`
```yaml
catalog_category: ""       # Required. Application | Technology | ABB | DataStore | DesignPattern
catalog_sub_type: ""       # Optional.
catalog_platform: ""       # Optional. (Sheet-level default; row uses hosting_* / platform_prior.)
catalog_repository: ""     # Optional.
catalog_url: ""            # Optional.
catalog_audience: []       # Optional.
catalog_dependencies: []   # Optional.
catalog_notes: ""          # Optional.
```
### 3. `register_entry`
```yaml
register_category: ""      # Required. Risk | OpenItem | Requirement | Interface | Prompt
register_source: ""        # Optional.
register_owner: ""         # Optional.
register_priority: ""      # Optional. High | Medium | Low | Content
register_dependency: ""    # Optional.
register_notes: ""         # Optional.
```
### 4. `compliance_review`
```yaml
review_work_package: ""    # Required.
review_outcome: ""         # Required. Approved | Approved with conditions | Rejected
review_approved_by: ""     # Required. "First name (date)"
review_checks: []          # Optional.
review_deviations: []      # Optional.
review_open_items: []      # Optional. IDs of open items.
review_infrastructure_findings: []  # Optional.
```
### 5. `stakeholder`
```yaml
stakeholder_role: ""       # Required.
stakeholder_concerns: []   # Required.
stakeholder_implications: [] # Required.
stakeholder_engagement: "" # Optional.
stakeholder_influence: ""  # Optional. High | Medium | Low
stakeholder_interest: ""   # Optional. High | Medium | Low
```
### 6. `constraint_or_principle`
```yaml
cp_kind: ""                # Required. Constraint | Principle | Rule | Intent
                           #   `Rule` added 2026-08-07 (OKF-TOGAF#45) for the
                           #   eleven corpus Rules migrated to corpus/rules.md.
                           #   `Intent` added 2026-08-20 (OKF-TOGAF#109) -- see
                           #   the Intent rows below.
                           #   Documentation-only: validate-corpus.js does not
                           #   enforce field enums, verified before landing.
cp_statement: ""           # Required for Constraint, Principle and Rule.
                           #   NOT USED ON AN INTENT ROW -- see below.
cp_source: ""              # Optional.
cp_scope: ""               # Optional.
cp_implications: []        # Optional.
cp_rationale: ""           # Optional.

# --- Intent rows (cp_kind: Intent) -------------------------------------
# The practice's own reason for existing (S0). One row per statement, in
# the owner's words.
intent_statement: ""       # Required for cp_kind: Intent. The statement
                           #   itself, verbatim as the owner authored it.
intent_nature: ""          # Optional. Classification of the statement.
```

**A worked `Intent` row.** The register ships empty — an empty S0 is the
defining signature of a germinated practice — so this is the only
conforming example a new owner has. Copy the shape, not the words.

```yaml
  - id: "INT-001"
    title: "Short name for the intent, not a sentence"
    cp_kind: "Intent"
    status: "Active"
    intent_statement: >
      One thing this practice exists to do, in the owner's own words.
      Written as a statement of purpose, not a goal with a date on it:
      an intent is what the practice is for, and it outlives the work
      items that realize it.
    intent_nature: "Optional. How this statement functions — originative, protective, positional."
```

**Three properties this shape has, and each is load-bearing:**

- **`intent_statement` is the required field, not `cp_statement`.**
  `cp_*` fields belong to constraints, principles and rules. **A tool
  reads `intent_statement` directly; a row using `cp_statement` will
  validate and recite blank.**
- **`title` is a name, not the statement.** The statement goes in
  `intent_statement`. A title that repeats it makes every recitation
  read twice.
- **One statement per row.** An intent register with one row containing
  four purposes cannot be cited, superseded or realized against
  individually.

**Work items fiber to these ids.** An `INT-*` id that nothing realizes
is an intent the practice is not acting on — **which is a finding, not
an error.**

> **`Intent` JOINS `cp_kind`, 2026-08-20**, ratified *"I ratify the
> `cp_kind` Intent amendment - David Facer - 8/20/2026"*, drafted by DT2 in
> `briefs/2026-08-20-beta-germination/05-DT2-s0-schema.md` §1.
>
> **This amendment documents what this practice already does; it does not
> change it.** `corpus/intent_register.md`'s rows have carried
> `intent_statement` and `intent_nature` since S0 was authored, and
> `tools/checkpoint-a.js` has read `intent_statement` throughout — **while
> this spec permitted only `Constraint | Principle | Rule` and never
> mentioned `intent_statement` at all.** Four items were non-conformant to
> this specification for months and nothing noticed, **because everything
> that consumes them was written against the items rather than against
> this document.**
>
> **Found by germination, not by review.** Two agents seeded from this
> corpus with no other context each hit the gap on their first governed
> act — recording S0 — and each invented a different representation. One
> guessed `intent_statement` and produced a corpus that validated while
> violating this spec; the other proposed `cp_statement`, **which would
> have passed validation and produced blank recitations**, because the
> checkpoint reads the other field.
>
> **WHY `cp_statement` IS NOT USED ON AN INTENT, which is the whole of the
> ruling:** `cp_*` means *constraint-or-principle*, and **an intent is
> neither.** Putting a statement of intent in `cp_statement` would give one
> field a fourth meaning — the defect class this practice has spent a
> fortnight removing from `seed`, `type` and `meta_date`. **A
> specification that has been silently wrong is corrected by describing
> reality, not by migrating reality to match the error.**
>
> **`tools/checkpoint-a.js` is deliberately unedited.** It is in the seed's
> shipping closure, so changing it would move every future seed and this
> practice's own S0 recitation in one edit — **a blast radius larger than
> the defect.**
### 7. `architecture_view`
```yaml
view_type: ""              # Required. Information | Data | Application | Technology | Capability
view_audience: []          # Required.
view_scope: ""             # Required.
view_governing_principle: "" # Optional.
view_placement_rules: []   # Optional.
view_domain_map: []        # Optional.
view_membership:           # Optional. Declarative selector for the generated ArchiMate view (see View Membership).
  include_ids: []          # Explicit element IDs to seed the view.
  include_layers: []       # ArchiMate layers to seed from: Business | Application | Technology | Motivation | Implementation.
  include_categories: []   # OKF catalog/register categories to seed from: Application | DataStore | ABB | Risk | ...
  include_context: []      # 1-hop role expansion: governance | data | realization.
```
### 8. `roadmap_entry`
```yaml
wp_owner: ""               # Required.
wp_timing: ""              # Optional.
wp_prerequisites: []       # Required.
wp_activities: []          # Required.  # NUMBERED SEQUENCES: CITE BY LABEL, NEVER BY POSITION -- see below.
wp_success_criteria: []    # Required.
wp_governance_gates: []    # Optional.
```

**NUMBERED SEQUENCES: CITE BY LABEL, NEVER BY POSITION** (added 2026-08-19, drafted by DT2 in `briefs/2026-08-18-seminum-packager/28-`, ratified *"I ratify both clauses - David Facer - 8/19/2026"*). **Labels in a numbered sequence may be non-contiguous.** `WP-SEMINUM-01.wp_activities` runs `1, 2, 3, 4, 9, 10, 11` — **seven entries, and *activity 9* is the fifth.**

**The first four entries make indexing look correct**, which is what catches a careful reader: DT2 indexed the ninth element, found nothing, and was one step from filing that a cited carrier did not exist (2026-08-19). **`RULE-5`’s carrier clause depends on this** — a carrier permitting *"the fifth element"* would send a reader to the wrong entry on the only item the convention has ever been used on.

**Do not renumber to close a gap.** The gap carries no meaning — it was arbitrary, and no label 5–8 has ever existed on that item — **but live citations do**: `roadmap.md`, DT briefs, CC reports and two GitHub issues all cite these labels. **Renumbering would break every one to tidy something that means nothing.**

**Measured 2026-08-19: six numbered-label sequences in the corpus, five contiguous, one not.** **No authoring convention is imposed**, deliberately: one requiring contiguity would be violated by exactly the item that motivated it, arriving already breached and unenforced on a population of six. **A reading rule protects all six and every future one, however written.**

### 9. `architecture_contract` (v1.5 — EXT-005)

The contract is the S4→S5 junction (SPEC-STRATA): the governed issuance of work to an implementation agent. Issuance is a manual gate — the committed, approved contract IS the issuance act. Rows live in `corpus/architecture_contracts.md` as an `items:` list (single file; a directory is premature at current volume).

**Type-index fields (constitutive — a contract missing either is ill-formed and fails validation):**

```yaml
realizes: ""               # Required, TYPE INDEX. The governed artifact this contract's work
                           #   realizes: a roadmap item (WP-XXX) or another governed artifact
                           #   whose own intent chain terminates in S0. Broadened from the
                           #   draft's WP-only wording so AC-002 (realizes a Standard) is
                           #   well-formed — divergence flagged in the WP-D6-01 report.
                           #   Non-empty; must resolve (Assertion Rule 5 namespaces).
ac_governing_refs: []      # Required, TYPE INDEX. Corpus/spec IDs governing the work.
                           #   Non-empty; every ID must resolve. The executing agent retrieves
                           #   each live before work (Rule 8 / Deputy TOGAF Contract Note).
```

**Remaining row fields:**

```yaml
ac_scope: ""               # Required. What this contract authorizes, and its boundary.
ac_prohibited: []          # Required. Explicit exclusions. May be [] only with a stated reason.
ac_acceptance: []          # Required. Checkable criteria. ALWAYS includes intent-conformance:
                           #   "delivered work realizes the governing chain, verified against
                           #   live originals."
ac_verification: ""        # Required. Verification classes required for key checks (SOP Rule 4).
ac_status: ""              # Required. Contract lifecycle: Draft | Issued | Complete | Amended.
                           #   (Type-local vocabulary — "Issued" and "Amended" are not shared
                           #   row-status values; the contract's issuance semantics need them.)
ac_issued_by: ""           # Required when ac_status is Issued or beyond. "Name (date)".
ac_checklist_ref: ""       # Optional. Pre-Deploy Checklist ID when deployment is in scope
                           #   (populates once WP-D6-02 lands the checklist as corpus items).
briefs: ""                 # Required when Issued or beyond. Correspondence folder junction
                           #   (relative path under briefs/), same convention as roadmap items.
ac_completion: ""          # Required when Complete. Outcome, commit hashes, deviations
                           #   summary, report reference.
```

**Naming note:** `realizes` is deliberately bare (not `ac_`-prefixed) despite Principle 10's prefix convention for this file class — it is the intent fiber's edge, named identically to the `realizes` relationship it encodes. The prefix rule's purpose is scope disambiguation; here the shared name IS the semantics. The `realizes` value is not additionally asserted as a `related:` edge — the type index IS the realization edge; duplicating it as a descriptive edge double-counts the relationship in the exported graph. *(Added 2026-07-18, rung (a) gap item 3 — codifies the pattern AC-001/002/003 already followed.)*

**Brief relationship (normative):** with a contract issued, the brief becomes thin transport ("Execute AC-XXX; archive contains N files") — the agent resolves the contract and its governing refs live. Briefs remain evidence (P-09); the contract governs.

---

### 10. `corpus_index` (v1.6 — EXT-006)

A singleton: exactly one file per EA OKF corpus carries this type — the root `README.md`. No `items:` list; the body is free-form prose (Rules, SOP, File Index) per Design Principle 7's prose-body tolerance. Exists solely so the one file every corpus has, and which no generic reader can afford to miss, carries the same `id` + frontmatter shape as everything else.

```yaml
type: "corpus_index"
id: ""                     # Required. Conventionally "SHEET-README".
title: ""                  # Required, EXCEPT where withheld by a `template` declaration (EXT-008 clause 5).
meta_status: ""            # Required. Same vocabulary as other sheets.
meta_version: ""           # Required.
meta_owner: ""             # Required.
related: []                # Optional.
```

No type-specific field prefix — a `corpus_index` file carries only the universal `meta_*` fields (Design Principle 1) plus the frontmatter block's `related:`. There is nothing to prefix because there are no row-level fields; the type exists purely to give the file an `id`.

---

### 11. `framework_entry` (v1.7 — EXT-007)

Ontology, Lexicon, and Taxonomy entries — the practice's own
meta-model, formalized from `market/ea-okf-ontology-lexicon-taxonomy.md`
into governed rows. Corpus home: `corpus/framework.md` (single file,
`items:` list, same pattern as `adrs.md`). Three categories share one
type because they share every field; `framework_category` is the only
axis of variance.

```yaml
framework_category: ""     # Required. "Ontology" | "Lexicon" | "Taxonomy".
display_order: 0           # Required. Integer. A schema-generic reader
                            #   sorts categories by this value rather than
                            #   hardcoding presentation order in
                            #   application code.
definition: ""              # Required. The plain-language definition,
                            #   transcribed from the market OLT document --
                            #   this field carries no new authorship.
stratum: ""                  # Optional. Populated only where the source
                            #   OLT document already assigns a stratum
                            #   (chiefly Lexicon terms). When present,
                            #   the row's related[] MUST include a
                            #   derives_from edge to SPEC-STRATA -- see
                            #   the Stratum rule below.
```

**The Stratum rule (normative, not merely a convention):** the eight-
stratum model (S0–S7) is never re-typed as `framework_entry` rows.
`SPEC-STRATA` (`spec/strata-and-intent-fibering.md`) remains sole
authority. Any `framework_entry` row that assigns a `stratum` value
must carry `related: [{id: "SPEC-STRATA", relationship: "derives_from"}]`
— a reference, never a restatement. This is the same discipline
behind the shared parse core (`tools/lib/corpus-parser.js`) and the
validator/Vellum "one parser, not two" rule, applied here to content
instead of code: one authoritative source, referenced everywhere it's
needed, never forked.

**Naming note:** `market/ea-okf-ontology-lexicon-taxonomy.md` (the OLT
document) is unaffected by this type's existence beyond one added
provenance line. It remains the right artifact for its stated
audience — plain-English, for readers outside the practice — while
`framework_entry` rows are the governed, machine-rendered counterpart
for the same content. Two artifacts, two audiences, one source of
truth per fact (never the same fact authored twice).

---

## Correspondence Vocabulary (v1.5, normative)

A **Work Package** is the governed unit of work (a `roadmap_entry` item). An **Architecture Contract** is its governed issuance to an implementation agent (an `architecture_contract` item). A **Brief** is DT→CC transport of an issuance. A **Report** is CC→DT evidence of execution. Contract and Work Package are S4 artifacts; brief and report are S6 evidence of S5 practice (SPEC-STRATA strata). Briefs and reports are archived under `briefs/` and are never load-bearing: anything in a brief that must bind future work is promoted into the corpus explicitly.

---

## Annotations (non-relationship cross-references)

| Field | On row types | Meaning | Archi mapping |
|---|---|---|---|
| `open_items: []` | any | IDs of Open Items tracking this element | Element property `EAOKF_OpenItems` (semicolon-separated); **not** a relationship |

**Migration rule (v1.3 → v1.4):** any `related_to` edge with an OpenItem on either endpoint moves to `open_items:` on the non-OI element (or on the OI itself if both endpoints are Open Items). Typed edges to registers (`realizes`, `derives_from`, `governed_by`) are **not** demoted.

---

## View Membership (generated ArchiMate views)

An `architecture_view` row may declare `view_membership:` to define — declaratively — which elements its generated ArchiMate diagram contains. Views **select** elements; they never define them (Principle 11).

**Resolution:**
1. **Seeds** = `include_ids` ∪ every element whose ArchiMate layer ∈ `include_layers` ∪ every element whose OKF category ∈ `include_categories`.
2. **Context** — 1-hop expansion by relationship *role*, from `include_context`:
   - `governance` — add elements linked to a seed by `governed_by` / `governs`
   - `data` — add elements linked by `depends_on`
   - `realization` — add elements linked by `realizes` / `instantiates`
3. **Connections** = every `related:` edge whose *both* endpoints are members. Annotations (`open_items:`) never appear as edges.

**Defaults** (applied when `view_membership` is absent, keyed on `view_type`):

| `view_type` | Default membership |
|---|---|
| `Application` | layers: [Application]; context: [governance, data] |
| `Information` | layers: [Business, Application]; context: [governance] |
| `Technology` | layers: [Technology, Application]; categories: [DataStore] |
| `Data` | categories: [DataStore]; context: [realization] |
| `Capability` | layers: [Business] |

In addition to the declared views, the exporter emits generic per-layer analytical views (Motivation / Application / Implementation). See `ameff-export-spec.md`.

---

## File Map (v1.4 target — 17 files)

| File | `type` | Category | Rows | v1.4 change |
|---|---|---|---|---|
| `catalog_applications.md` | `catalog_entry` | `Application` | 10 | **+A10 Executive Readout Service** (was AC-003) |
| `catalog_tech_components.md` | `catalog_entry` | `Technology` | 16 | — |
| `catalog_data_stores.md` | `catalog_entry` | `DataStore` | 7 | DS↔DS links → `shares_infrastructure_with` |
| `catalog_abb.md` | `catalog_entry` | `ABB` | 5 | — |
| `catalog_design_system.md` | `catalog_entry` | `DesignPattern` | 9 | — |
| `register_open_items.md` | `register_entry` | `OpenItem` | 34 | element links become `open_items:` annotations |
| `register_risks.md` | `register_entry` | `Risk` | 6 | — |
| `register_requirements.md` | `register_entry` | `Requirement` | 6 | — |
| `register_interfaces.md` | `register_entry` | `Interface` | 6 | — |
| `register_prompts.md` | `register_entry` | `Prompt` | 1 | — |
| `adrs.md` | `architecture_decision_record` | — | 5 | — |
| `compliance_reviews.md` | `compliance_review` | — | 5 | — |
| `stakeholders.md` | `stakeholder` | — | 6 | — |
| `constraints.md` | `constraint_or_principle` | `Constraint` | 7 | — |
| `principles.md` | `constraint_or_principle` | `Principle` | 8 | — |
| `architecture_views.md` | `architecture_view` | — | 3 | `VIEW-AC-01` references A2/A4/A10; defines nothing |
| `roadmap.md` | `roadmap_entry` | — | 5 | — |

**Retired IDs:** `AC-001` → `A2`, `AC-002` → `A4`, `AC-003` → `A10` (all references retargeted).

---

## Archi Integration Notes

> **Export format settled (v1.4).** The canonical export is the **Open Group ArchiMate Model Exchange File Format (AMEFF)** — one tool-neutral XML file carrying elements, relationships, typed properties, model organization, and generated views. See `ameff-export-spec.md`. The three-file CSV import (`archi-csv-import-spec.md`) is retained as legacy. The rules below hold regardless of format.

**Element mapping:** Each item in a `catalog_entry` or `register_entry` body maps to one ArchiMate element. `archimate.element_type` at item level is the element type; `archimate.layer` determines the layer.

**Relationship mapping:** Each `related[]` entry maps to one relationship (source = containing item, target = `related[].id`). Use the ArchiMate analog column to map `relationship` values.

**Annotations do not map to relationships:** `open_items:` becomes an element property, keeping Open Items out of the relationship graph.

**Sheets are non-exported:** sheet-level `related:` is documentation-level and is not emitted as ArchiMate relationships. (If visual grouping is later desired, a sheet maps to an ArchiMate `Grouping` element — deferred.)

**Why discipline matters:** Principles 11 and 12 plus the amended Rules keep the exported graph to genuine architecture relationships between uniquely-defined elements — the condition for readable, derivable views.

---

## Next Steps

1. ~~**Settle the import/export approach**~~ — ✅ done. AMEFF chosen (`ameff-export-spec.md`).
2. ~~**Corpus migration**~~ — ✅ done. `A10` added, `AC-*` retired, open-item links demoted, DS↔DS re-typed. Verified: `related_to` 13.6% (<15%); 0 dangling refs on export. Density 1.57 — above the 1.2 target but composed of legitimate `realizes` / `derives_from` traceability; accepted.
3. ~~**Schema lock**~~ — ✅ **v1.4 locked Active 2026-07-09.** Further structural change requires a new version + ADR.
4. **D6 Governance corpus** — first production use of the locked schema (next initiative).

---

> TOGAF® is a registered trademark of The Open Group. EA OKF is not affiliated with, endorsed by, or certified by The Open Group.
>
> OKF (Open Knowledge Format) is an open specification from Google Cloud, Apache 2.0 licensed. EA OKF is an OKF v0.1 profile — not affiliated with or endorsed by Google.
