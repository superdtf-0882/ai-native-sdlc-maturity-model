---
type: constraint_or_principle
id: "SPEC-STRATA"
title: "Strata and Intent Fibering — Concept Note"

meta_status: "Active"
meta_version: "2.3"
meta_owner: "David"
meta_initiative: "d6-governance"
meta_date: "2026-07-30"

togaf:
  phase: "Preliminary/Phase A"
  artifact_type: "Architecture Principles Catalog"

archimate:
  layer: "Motivation"
  element_type: "Meaning"

related:
  - id: "P-09"
    relationship: "derives_from"
---

# Strata and Intent Fibering
**SPEC-STRATA · v2.3 Active — ratified 2026-08-01** (David, direct, in response to `briefs/2026-07-30-digest-meta-instructions/02-CC-report.md`: "I ratify this. Let's move forward")

> The theoretical frame for intent-driven, spec-driven automation in
> this practice. Cited by: the architecture_contract type (EA OKF
> v1.5), the D6 scoring instrument (WP-D6-04), the Deputy TOGAF
> Deployment Guide (WP-D6-05), and the D4 dimension revision.

---

## The eight strata

Everything the practice touches sits on one of eight strata. Knowing
which stratum a statement lives on determines what kind of statement
it is allowed to be. The strata carry Latin designations — stable,
formal, system-level terms, always paired with their number in prose.

| Stratum | Name | What it contains | This practice's instances |
|---|---|---|---|
| S0 | *Intent* | The originating motivation for the practice, ineffable until elucidated. Not a governed artifact until then — see Schema consequences (4). | Elucidated as the intent register (INT-*) — see Schema consequences (4) |
| S1 | *Fundamentum* | The first governed expression of Intent. Principles, foundational constraints, charters, and Architecture Visions — generated directly from Intent. | Principles (P-*) · foundational constraints (C-*) · CHARTER-DT · CHARTER-CC · Architecture Visions (AV-*, the `architecture_view` rows carrying `vision_*` fields — e.g. AV-STRATUM-001; distinct from this same file's ordinary View rows, VIEW-*, which stay at S4 — see Schema consequences (5)) |
| S2 | *Normae* | External standards and maturity models the practice measures itself against. Adopted, not generated — selected in service of Fundamentum. | TOGAF® · the AI-Native SDLC Maturity Model (STD-SDLC-MM) |
| S3 | *Vocabula* | The shared, precise language making S2 checkable and S4 consistent. Schema, lexicon, and taxonomy documents. | EA OKF (the bundle spec and extension registry) · the OLT explainer |
| S4 | *Corpus* | The single governed archive. Location, not authority — an artifact may be in the Corpus without itself being a governing rule. | The corpus/ archive: ADRs, views, registers, contracts-as-records |
| S5 | *Auctoritas* | The formal machinery by which work is sanctioned and handed off. Issuance is the constitutive act; the Architecture Contract is its instrument. | The SOP: work packages, briefs, contracts, the Rules — each with a resolvable ID (`corpus/rules.md`); issuance acts |
| S6 | *Operationes* | The live systems, tools, and processes doing actual work day to day. | CC runs, deployed applications, live infrastructure |
| S7 | *Observatio* | The feedback layer. Closes back to S0 — what is learned from operations sharpens Intent over time. | Canaries, sweeps, maturity assessments, reports, open items |

**Ordering principle.** The stack is ordered by generative immediacy
from Intent — not by durability, importance, or precedence of
enforcement. Fundamentum (S1) precedes Normae (S2) because
principles, charters, and foundational constraints are generated
*directly* from Intent, while standards are subsequently **selected**:
instruments adopted in service of what Fundamentum has already
established. Adoption, not authorship, is what places a standard at
S2 — even a standard the practice itself originated becomes, once
published, versioned, and citable as its own artifact, something the
practice *adopts*, and therefore sits downstream of Fundamentum
regardless of who wrote it. The stack remains generative, not
descriptive: it originates at Intent and refines downward.
Fundamentum is simply Intent's more immediate emanation.

S6 is not "the real thing described by the layers above" — it is the
environment in which a design executes. And the stack is a cycle, not
a hierarchy: S7 returns to S0. The transit time of that return arc is
D13 — feedback loop velocity is the loop's period, measured.

Three boundaries fall out of the stack:
- **S4/S5 is the record/authority boundary**: presence in the corpus
  does not itself confer operative authority. A filed artifact is not
  an issued artifact.
> **Owner's standing position on this boundary, recorded 2026-08-15
> (David).** *"I think there is a maturity threshold. At low maturity, a
> practice is served by keeping that line clear. At higher maturity
> levels, they will organically blur. Currently, we are below that
> threshold. But the question I have, and I don't know honestly, is what
> are the consequences for a practice that crosses that threshold in the
> future?"*
>
> **Closure criterion, which this question did not previously have:**
> *"This will remain open until we prove a reliable low-maturity
> process."*
>
> So the boundary is held **deliberately sharp because the practice is
> below the threshold**, not because the sharp reading is believed to be
> finally correct. Two things follow. The blur is predicted to be
> *organic* — something a maturing practice does rather than something a
> spec should legislate early. And the open question is not "where is
> the line" but **what crossing it costs a practice later**, which is
> unanswered and is stated as unanswered.
>
> Recorded here rather than in a second artifact because this file
> already owns the question; a duplicate would be `C-008`'s shape. It is
> recorded at all because `SD-2026-08-15` established that reasoning
> left in conversation is invisible to the record by construction —
> which had already cost one wrong conclusion that same day.

- **S5/S6 is the sanction/runtime boundary** — the build-time/runtime
  line, and the site of D12's non-determinism question ("where does
  non-determinism live?"). This boundary is genuinely difficult to
  state precisely: whether an AI agent producing a record,
  participating in sanction, executing sanctioned work, and
  generating evidence about that execution constitutes one act or
  several — especially when one agent performs all of this in
  seconds — does not yet have a settled answer here. Flagged as
  evolving, not resolved.
- **S6/S7 is the operation/evidence boundary**: runtime behavior
  becomes evidence before it can legitimately revise governance or
  intent.

P-09 expressed precisely: the corpus is the exclusive home of
governing record; Auctoritas determines what within that record
carries operative force; everything outside the governed record
evidences but does not govern.

## v1 → v2 translation

Permanent. Everything filed before 2026-07-20 — briefs, digests,
workbooks, prior spec versions — uses v1 lettering, frozen to its
era and never retro-edited. Read old citations through this table:

| v1 stratum | v2 stratum | Note |
|---|---|---|
| S0 | S0 | Unchanged |
| S1 | S2 | Enterprise patterns → Normae |
| S2 | S3 | Semantic layer → Vocabula |
| S3 | **S1 and S4** | Split: governing-function content (principles, charters, constraints) → S1 Fundamentum; corpus-as-location content → S4 Corpus |
| S4 | S5 | Implementation practices → Auctoritas |
| S5 | S6 | Execution environment → Operationes |
| S6 | S7 | Monitoring & telemetry → Observatio |

Historically, every structural error this practice has corrected was
a stratum error: evidence claiming governance (workbook-as-truth),
runtime data entering the corpus (rejected ADR-007 Option B),
documents claiming authority they did not have (xlsx-as-source-of-
truth, fixed at model v1.0).

## Descent and audit: apo and para

Intent must survive seven levels of refinement. A naive descent — each
stratum consuming only its parent's output — is a catamorphic fold:
locally faithful at every step, globally drifted by the bottom. The
telephone game, formalized.

The practice's descent is instead **apomorphic**: each refinement
step embeds a resolvable reference to the original, not merely an
elaboration of the parent. The audit direction is **paramorphic**:
conformance is checked at every level against the preserved original,
not the immediate parent. Rule 8 (corpus by reference) is the
operational form: an agent at S5 does not receive a paraphrase of
CHARTER-001 — it resolves CHARTER-001.

## Intent as fiber, not process

The stronger form, and the one this practice adopts: intent is not
an external thread audited alongside the artifacts — it is a **fiber
inside every morphism**. In dependent-type terms, a governed
artifact's type is indexed by the intent it realizes: not
`ArchitectureContract` but `ArchitectureContract(i : Intent)`. An
artifact that realizes nothing is not an invalid artifact; it is
**ill-typed — unconstructible**.

In lens terms: descent is `put` (refine, embedding origin), audit is
`get` (project back to intent), and the lens round-trip law is the
paramorphic guarantee stated as algebra.

### The two-index generalization (added v2.3, ratified 2026-08-01)

The form above indexes an artifact by the intent it realizes. The
general form indexes by **both** the intent and the stratum the thing
occupies:

```
GovernedThing[S](i : Intent)
```

In compact notation, as an assertion about a specific thing:

```
thing : LegalType @ LegalStratum realizes Intent
```

Four distinct failure modes follow, and they are not
interchangeable — each names a different thing that is wrong:

| Missing or illegal | The thing is |
|---|---|
| Legal type | **undefined** — there is no artifact class it belongs to |
| Stratum (missing or illegal) | **misplaced** — it exists but sits nowhere legitimate |
| Intent (missing or unresolved) | **ill-typed** — unconstructible, per the fiber rule above |
| Authority | **unactionable** — well-formed, but nothing licenses acting on it |

The last is the one most easily missed: a thing can be correctly
typed, correctly placed, and correctly fibered to a real intent, and
still not be actionable, because being well-formed is not the same as
being authorized.

**Provenance note, stated rather than hidden:** this two-index form
and its failure taxonomy were first written down in
`briefs/2026-07-27-strata-representation/` and landed publicly in
aimaturitymodels.com's AI-readable digest (instruction S4) before
they existed anywhere in this corpus — meaning the practice's own
type theory was, for three days, canonical only in a public artifact
and in brief files that bind nothing under P-09 and Rule 8. Found by
CC while answering DT's source-of-truth question
(`briefs/2026-07-30-digest-meta-instructions/`), and landed here to
correct it. The digest now restates this section rather than being
its only home.

### Fiber and feedback are different (added v2.3, ratified 2026-08-01)

These are routinely conflated and should not be. **The intent fiber
is not a loop.** It is present throughout every valid descent from S0
to S7 — a governed thing without a resolved intent reference is
ill-typed at any stratum, not merely at the ends.

**Feedback is a separate, additional claim:** S7 (*Observatio*)
returns findings to S0 (*Intent*) so that intent itself can be
reconsidered — closing a loop the fiber's own presence does not by
itself require. A stratum can carry the fiber correctly with no
feedback event having occurred yet; and feedback, when it does occur,
still has to carry its own resolved intent reference to be real, the
same as everything else.

### "Consequential," defined (added v2.3, ratified 2026-08-01)

The typing discipline above applies before any **consequential**
undertaking. That term was load-bearing but never defined, which left
it to each reader's judgment. A checkable test:

> An undertaking is **consequential** when treating it as real would
> create, change, approve, commit, deploy, publish, allocate, bind,
> or retire a governed thing — or otherwise exercise authority.

Analysis, explanation, and hypothetical drafting are **not**
consequential merely because the subject matter is important.
Thinking about a contract is not issuing one; describing a deployment
is not deploying.

The practical inversion this produces:

| | External-process model | Fiber model |
|---|---|---|
| Enforcement | Sweep finds orphans after the fact | Construction fails at parse time |
| Violations are | Found | Unrepresentable |
| Conformance is | Audited | Typed |

## Schema consequences (normative)

1. **The `realizes` edge is constitutive, not descriptive.** On
   governed artifact classes (beginning with `architecture_contract`
   in EA OKF v1.5), `realizes` and `ac_governing_refs` are type
   indices: required, non-empty, resolution-validated at parse. The
   other relationship types remain descriptive.
2. **Legal fiber namespaces** are exactly three: corpus row items,
   corpus sheet-level IDs, and spec-document IDs (any document with
   a frontmatter `id:`). Free-floating mnemonics cannot carry the
   fiber and are illegal `related:` targets.
3. **Transitive termination at S0** — every governed artifact's
   intent chain resolves, transitively, to an S0 intent register
   entry — is checked by instrument (WP-D6-04), not at parse.
   Parse-time gives shallow typing; the instrument gives chain
   integrity. Both are required for the fiber to be real.
4. **S0 must exist as an artifact class** (the intent register)
   before the transitive check can run. This does not collapse the
   distinction between originating intent and its elucidation: intent
   precedes the governed system and is ineffable until articulated;
   the register is intent's first addressable representation, not
   intent itself. The register does not create intent — but no
   governed descent can begin until intent has been elucidated there.
   Three to five statements, owner-authored — intent cannot be
   elucidated by delegation.
5. **Architecture Visions (S1) and ordinary Views (S4) share a file
   but not a stratum.** Both are rows in `corpus/architecture_views.md`
   (`type: architecture_view`), but they are not the same kind of
   thing. A Vision (e.g. `AV-STRATUM-001`) carries `vision_*` fields
   — scope, constraints, non-goals, risks, success criteria,
   sequencing — cites a `realizes` edge directly to an S0 intent
   statement, and is time-bound (it can be superseded once its
   initiative concludes, as `AV-BROWSER-001` was). It is generated
   directly from Intent, the same immediacy that places Principles
   and Charters at S1. An ordinary View (`VIEW-IA-01`, `VIEW-AC-01`,
   `VIEW-BASELINE-01` — Information/Application/Technology
   viewpoints) is a rendering *of* the architecture, not a generative
   act from Intent — it stays at S4, the location the stratum table
   already named. The distinguishing test is structural, not
   editorial judgment: presence of `vision_*` fields places a row at
   S1; their absence leaves it at S4.

## The honest boundary

Schema validation gives *shallow* dependent typing: the index exists
and resolves. It cannot give *semantic* fibering: that the artifact
genuinely realizes the intent it cites rather than merely pointing at
it. That gap is unclosable by structure, and the practice does not
pretend otherwise. Semantic conformance is a judgment — which is
precisely what the deliberately-manual gates (ADR approval, contract
issuance, Compliance Review sign-off) exist to supply.

**Structure makes unreferenced intent unrepresentable. Judgment makes
misreferenced intent catchable.** That division of labor is the honest
meaning of "enforceable intent," and it is the same division that
keeps certain D6 gates manual at Maturity C by design.

## One-paragraph formal summary

The practice is a stratified, fibered structure over Intent: each
stratum contains intent-indexed artifacts, and every valid descent
morphism transports the originating intent fiber through the
refinement. The fiber does not connect the strata as separate,
otherwise-independent layers — it is woven through the artifacts and
morphisms by which the strata constitute one architecture, not
stitched on afterward. Strata tell us where a thing is. The fiber
preserves what it is for.

## Related visuals

Current (v2, eight strata): `docs/intent-strata-stack-2026-07-20.svg`
(rail model — the audited form, kept as the teaching contrast) and
`docs/intent-fibered-strata-stack-2026-07-20.svg` (fiber model — the
adopted form). The difference between the two diagrams is the
difference between tracked intent and typed intent. The 2026-07-16
pair renders the v1 seven-strata model and is retained
superseded-by-date; read its letters through the translation table.

## Changelog

- **2026-08-20 — S5 row stops naming a count, no version bump.** *"the
  twelve Rules (`RULE-1`–`RULE-10` plus `RULE-5B`/`RULE-5C` …)"* → *"the
  Rules — each with a resolvable ID …"*. Ratified *"Land the SPEC-STRATA
  reword - David Facer - 8/20/2026"*; drafted by DT2 in
  `briefs/2026-08-20-beta-germination/05-` §2. **A pointer correction, not
  a provision change** — the same treatment the two entries below record.

  **THIS IS THE THIRD TIME THIS ROW HAS GONE STALE, AND THE FIRST TIME THE
  CONSTRUCTION ITSELF WAS REMOVED RATHER THAN RE-POINTED.** The two
  corrections below each fixed the number and left the shape that
  guarantees it goes stale again. `OI-055` registers the class — five live
  sentences naming the Rule count — and DT2's reading is that **a
  shipping document must not assert the corpus's composition: it may name
  what it governs, it may not enumerate what exists.**

  **What made it urgent was germination, not review.** This document ships
  in a Seminum seed as runtime data — byte-for-byte, unsplit — and a seed
  deliberately carries **fewer** Rules than this corpus. **So the
  staleness stopped being a risk and became a false statement a recipient
  meets on arrival**, found by an agent germinated from this corpus:
  *"This seed contains nine Rules despite `SPEC-STRATA` declaring
  twelve."*

  **The enumeration went with the count, and that was the second fault.**
  The row named `RULE-5B` and `RULE-5C` by ID; **neither ships**, so a
  recipient met two unresolvable identifiers alongside the wrong number.
  **One rewording closed both.**

  **The four earlier mentions of the count in this changelog are
  deliberately untouched.** They are the record of the row going stale,
  and correcting them to suit the present is the rewriting this practice
  refuses — the same rule that left `AV-BROWSER-001` alone.

- **2026-08-14 — S5 row repointed, no version bump.** *"the eleven Rules
  (`RULE-1`–`RULE-9` …)"* → *"the twelve Rules (`RULE-1`–`RULE-10` …)"*,
  consequent to `RULE-10`'s ratification. A pointer correction, not a
  provision change — same treatment as the charters received for the
  same act.

  **This is the SECOND time this row has gone stale in the same way.**
  `corpus/rules.md`'s `provenance_note` records the first: *"SPEC-STRATA's
  S5 row said 'Rules 1-9' when eleven exist,"* corrected 2026-08-07.
  Seven days later it said eleven when twelve exist. **Both times the row
  was missed by a deliberate sweep** — on 2026-08-13 DT enumerated nine
  stale references across four files and CC verified each at its line
  number, and neither party's search reached this file. The row is a
  standing candidate for going stale on every future change to the Rule
  count, and this note exists so the third occurrence is recognised as a
  third rather than discovered fresh.

- **v2.3 — 2026-07-30, ratified 2026-08-01 (David, direct: "I ratify this. Let's move forward").** Three
  additions to the fibering section, all grounding theory that was
  already in use but had no canonical home: (1) the two-index
  generalization `GovernedThing[S](i : Intent)`, its compact
  assertion form, and the four-way failure taxonomy
  (undefined / misplaced / ill-typed / unactionable); (2) the
  fiber-vs-feedback distinction, stated explicitly because the two
  are routinely conflated; (3) a checkable definition of
  "consequential," a term this spec's own discipline depended on
  without ever defining. Origin: `briefs/2026-07-30-digest-meta-
  instructions/` — CC, answering DT's source-of-truth question,
  found that (1) and (2) existed **only** in aimaturitymodels.com's
  public digest and in `briefs/2026-07-27-strata-representation/`,
  which binds nothing under P-09 and Rule 8. (3) was proposed in the
  same brief as an operationalization an external reader needs.
  Nothing here changes the strata themselves or the fiber rule; it
  writes down what was already being relied on.
- **v2.2 — 2026-07-25.** Small addition, not a remodel: Architecture
  Visions given an explicit S1 (Fundamentum) instance, closing a real
  gap DT found while testing a real case against the spec (David
  proposed classifying an aspirational vision narrative against S0;
  it didn't fit S0's owner-authored, three-to-five-terse-statements
  shape, and checking where it *did* fit surfaced that Visions had no
  named home anywhere in the stratum table at all). New Schema
  Consequence 5 makes the distinction structural, not editorial:
  presence of `vision_*` fields places an `architecture_view` row at
  S1 (e.g. `AV-STRATUM-001`); their absence leaves ordinary View rows
  (`VIEW-IA-01`, `VIEW-AC-01`, `VIEW-BASELINE-01`) at S4, exactly
  where the table already put them. Citation-ripple check clean — no
  existing corpus content asserts or depends on S1's instance list
  being closed. `corpus/README.md`'s own separate, informal
  Item-type/stratum table was found to have the identical omission
  while checking; corrected in the same pass for consistency. Origin:
  `briefs/2026-07-25-spec-strata-vision-gap/`.
- **v2.1 — 2026-07-22.** Three refinements to the v2.0 remodel, not a
  restructure. (1) S0's table cell shortened to name the ineffable-
  until-elucidated character of Intent, with the fuller reasoning
  moved to an expanded Schema Consequence 4 (the register is intent's
  first addressable representation, not intent itself — it does not
  create intent, but no governed descent can begin until intent is
  elucidated there). (2) The one-paragraph formal summary's "strata
  are fibers" framing replaced: the fiber is woven through the
  artifacts and morphisms that constitute one architecture, not
  stitched onto separate layers afterward — strata tell us where a
  thing is, the fiber preserves what it is for. (3) The two derived
  boundaries become three, correctly flanking S5 (Auctoritas) instead
  of skipping over it: S4/S5 (record/authority), S5/S6
  (sanction/runtime — genuinely unresolved: whether one AI agent
  producing a record, sanctioning, executing, and generating evidence
  in seconds is one act or several, flagged as evolving, not
  resolved), and S6/S7 (operation/evidence), tied back to P-09's own
  language.
  **Provenance, stated in full:** these edits did not originate inside
  this practice's own sessions. Craig — an ontologist substantially
  responsible for this practice's current architecture across several
  prior conversations with David — worked through SPEC-STRATA's
  reasoning with David directly. David then brought that conversation
  to ChatGPT for independent consultation, which produced these three
  edits, including catching a real inconsistency between the
  document's own summary paragraph and its "Intent as fiber" section.
  Worth recording as more than attribution: introducing this
  architecture to a different ontologist, then to a different AI
  model with zero access to this corpus's shared history, and having
  it independently produce a formally sound correction is itself
  evidence for the thesis this practice has been testing throughout —
  that a disciplined ontology/lexicon/taxonomy/semantics architecture
  is apprehensible and scalable across LLM agents without the drift
  traditional audited systems accumulate. Origin:
  briefs/2026-07-22-spec-strata-v21/ (finalized content from David and
  DT; this landing).
- **v2.0 — 2026-07-20.** Eight-strata remodel with Latin
  designations: Fundamentum (S1) carved out of v1's S3 (governing-
  function artifacts get their own stratum; the corpus remains their
  location); Vocabula (S3) renamed and sharpened from v1's S2
  semantic layer; all subsequent letters shifted. Ordering principle
  added (generative immediacy; adoption-not-authorship places even
  self-originated standards at Normae). Permanent v1→v2 translation
  table added; derived boundary mnemonics re-lettered (P-09 line now
  S4/S6; build-time/runtime now S5/S6). Origin:
  briefs/2026-07-20-spec-strata-v2-consultation/ (round 1),
  briefs/2026-07-20-spec-strata-v2-round2/ (round 2),
  briefs/2026-07-20-spec-strata-v2-execution/ (this landing).
- **v1.0 — 2026-07-16.** Initial concept note: seven strata,
  apo/para descent-audit, intent fibering, schema consequences.
